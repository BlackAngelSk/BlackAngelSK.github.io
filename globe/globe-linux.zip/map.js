/* =====================================================
   Interactive Detailed Map with Custom Line Annotations
   ===================================================== */
// @ts-nocheck
/* global L, html2canvas */
'use strict';

/* ── State ────────────────────────────────────────── */
const S = {
    tool: 'pan',
    color: '#ff0000',
    weight: 3,
    dashStyle: 'solid',
    drawing: false,
    annotations: [],
    nextId: 1,
    /* freehand */
    fhPoints: [],
    fhLine: null,
    /* eraser */
    eraserHandlers: [],
    eraserDragging: false,
    eraserErasedIds: new Set(),
    /* touch fallback */
    lastLatLng: null,
    /* undo/redo */
    undoStack: [],
    redoStack: [],
    /* arrow */
    arrowStart: null,
    arrowLine: null,
    arrowHead: null,
    arrowDrawing: false,
    flag: null,
    /* measure */
    msPoints: [],
    msLine: null,
    msLabels: [],
    msPreview: null,
    /* label input */
    labelLatLng: null,
    /* region highlight */
    highlighted: null,
    highlightedOrigStyle: null,
    /* border/region pulse */
    _pulseTimer: null,
    _pulsePhase: 0,
    /* rivers */
    _riversData: null,
    _riversLayer: null,
    _riversVisible: false,
    _riversLoading: false,
};
const UNDO_LIMIT = 50;

/* ── Highlight Pulse Animation ─────────────────── */
function _startPulse(layer, baseStyle) {
    _stopPulse();
    S._pulsePhase = 0;
    S._pulseTimer = setInterval(function () {
        S._pulsePhase = (S._pulsePhase + 1) % 40;
        var t = S._pulsePhase / 20;          // 0 → 1 → 0
        if (t > 1) t = 2 - t;
        var w = baseStyle.weight + t * 2;     // weight oscillates ±2
        var a = baseStyle.fillOpacity + t * 0.08;
        layer.setStyle({
            weight: w,
            fillOpacity: Math.min(a, 0.50)
        });
    }, 60);
}
function _stopPulse() {
    if (S._pulseTimer) { clearInterval(S._pulseTimer); S._pulseTimer = null; }
}

const COLORS = [
    '#ff0000', '#ff8800', '#ffdd00', '#00cc44', '#00bbff',
    '#0066ff', '#9900ff', '#ff00aa', '#ffffff', '#333333'
];
const DASH = { solid: null, dashed: '12, 8', dotted: '4, 8' };
const STATUS = {
    pan: 'Ready — Pan mode',
    freehand: 'Click and drag to draw',
    arrow: 'Click and drag to draw an arrow',
    marker: 'Click to drop a pin on the map',
    label: 'Click to place a text label',
    measure: 'Click to measure distance · Dbl-click / Enter to finish · Esc to cancel',
    eraser: 'Click an annotation to erase it',
    fire: 'Click to place a fire on the map'
};

/* ── DOM shortcuts ────────────────────────────────── */
const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);

/* ── Map init ─────────────────────────────────────── */
const canvasRenderer = L.canvas({ padding: 0.5 });
const map = L.map('map', {
    center: [48.15, 17.11],
    zoom: 6,
    minZoom: 2,
    maxZoom: 19,
    zoomControl: true,
    doubleClickZoom: false,
    preferCanvas: true
});

/* Keep Leaflet's viewport in sync when the browser viewport or the map
   container changes size (fullscreen, mobile browser chrome, split view,
   or a resized window). */
const mapElement = document.getElementById('map');
let mapResizeFrame = 0;
function requestMapResize() {
    if (mapResizeFrame) cancelAnimationFrame(mapResizeFrame);
    mapResizeFrame = requestAnimationFrame(() => {
        mapResizeFrame = 0;
        map.invalidateSize({ pan: false, debounceMoveend: true });
        if (typeof clampDraggablePanels === 'function') clampDraggablePanels();
    });
}
if (typeof ResizeObserver !== 'undefined') {
    new ResizeObserver(requestMapResize).observe(mapElement);
}
window.addEventListener('resize', requestMapResize);
window.addEventListener('orientationchange', requestMapResize);
if (window.visualViewport) window.visualViewport.addEventListener('resize', requestMapResize);

/* ── Tile layers (zoom-dependent density) ─────────── */
const osm = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, crossOrigin: true,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a>'
});
const topo = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, maxNativeZoom: 17, crossOrigin: true,
    attribution: '&copy; <a href="https://opentopomap.org">OpenTopoMap</a>'
});
const sat = L.tileLayer(
    'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    maxZoom: 19, maxNativeZoom: 18, crossOrigin: true,
    attribution: '&copy; <a href="https://www.esri.com">Esri</a>'
});
/* ── Fullscreen Button (injected into zoom control) ─── */
map.whenReady(function () {
    var zoomCtrl = document.querySelector('#map .leaflet-control-zoom');
    if (zoomCtrl) {
        var btn = document.createElement('button');
        btn.id = 'btn-fullscreen';
        btn.className = 'leaflet-control-fullscreen';
        btn.title = 'Toggle fullscreen (F)';
        btn.textContent = '\u26F6';
        zoomCtrl.appendChild(btn);
    }
});

osm.addTo(map);

/* Layer control — Standard, Topographic, Satellite (all free, no API keys) */
L.control.layers({
    '\u{1F5FA} Standard': osm,
    '\u{1F3D4} Topographic': topo,
    '\u{1F6F0} Satellite': sat
}, null, { position: 'topright' }).addTo(map);

/* ── Map Label Languages ─────────────────────────── */
const LANGUAGES = [
    { code: 'EN', flag: '🇬🇧', url: 'https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png', max: 19, attr: '© CARTO © OSM' },
   /* { code: 'SK', flag: '🇸🇰', url: 'https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png', max: 19, attr: '© CARTO © OSM' },
    { code: 'DE', flag: '🇩🇪', url: 'https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png', max: 19, attr: '© CARTO © OSM' },
    { code: 'JP', flag: '🇯🇵', url: 'https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png', max: 19, attr: '© CARTO © OSM' },
    */ { code: 'OFF', flag: '🚫', url: '', max: 19, attr: '' }
];
let langIdx = -1;
let langOverlay = null;

function setMapLanguage(idx) {
    langIdx = idx % LANGUAGES.length;
    const lang = LANGUAGES[langIdx];
    if (langOverlay) { map.removeLayer(langOverlay); langOverlay = null; }
    if (lang.url) {
        langOverlay = L.tileLayer(lang.url, { maxZoom: lang.max, crossOrigin: true, attribution: lang.attr, pane: 'overlayPane' });
        langOverlay.addTo(map);
    }
    $('#btn-lang').innerHTML = '<span class="lang-flag">' + lang.flag + '</span><span class="lang-code">' + lang.code + '</span>';
    parseEmoji($('#btn-lang'));
}
$('#btn-lang').addEventListener('click', () => setMapLanguage(langIdx + 1));

/* Use the base map's native labels by default. Load the optional label overlay only on demand. */
$('#btn-lang').innerHTML = '<span class="lang-flag">' + LANGUAGES[0].flag + '</span><span class="lang-code">' + LANGUAGES[0].code + '</span>';
parseEmoji($('#btn-lang'));

/* =====================================================
   Country Borders & Regions — progressive drill-down
   =====================================================
   Click  "Borders"    → show all country outlines
   Dbl-click a country → only that country visible
   Zoom in (≥ 6)       → admin-1 regions appear inside it
   Dbl-click a region  → only that region visible
   Dbl-click again     → go back one level
   ===================================================== */
var BORDERS_GEOJSON_URL = 'https://raw.githubusercontent.com/holtzy/D3-graph-gallery/master/DATA/world.geojson';
var REGIONS_GEOJSON_URL = 'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_admin_1_states_provinces.geojson';
var REGION_MIN_ZOOM = 6;

/* --- state ------------------------------------------------ */
var _bordersData   = null, _bordersLayer = null;
var _bordersLoading = false, _bordersVisible = false;
var _allCountryLayers = [];
var _borderClickTimer = null;

var _selCountryLayer = null, _selCountryName = null, _selCountryOrig = null;

var _regionsData   = null, _regionsLoading = false;
var _regionsLayer  = null, _allRegionLayers = [];

var _selRegionLayer = null, _selRegionOrig = null;

/* --- polygon centroid helper (largest ring) --------- */
function _polygonCentroid(layer) {
    var rings = [];
    layer.eachLayer(function (l) {
        if (l.getLatLngs) {
            var ll = l.getLatLngs();
            /* MultiPolygon -> array of arrays of arrays */
            if (ll.length && ll[0].length && ll[0][0] && ll[0][0].length) {
                ll.forEach(function (poly) { poly.forEach(function (ring) { rings.push(ring); }); });
            } else if (ll.length && ll[0].length && ll[0][0]) {
                /* Polygon -> array of arrays */
                ll.forEach(function (ring) { rings.push(ring); });
            } else if (ll.length) {
                rings.push(ll);
            }
        }
    });
    if (!rings.length) return layer.getBounds().getCenter();
    /* pick the ring with the most points (= mainland) */
    rings.sort(function (a, b) { return b.length - a.length; });
    var ring = rings[0];
    var lat = 0, lng = 0;
    for (var i = 0; i < ring.length; i++) {
        lat += ring[i].lat || ring[i][0] || 0;
        lng += ring[i].lng || ring[i][1] || 0;
    }
    return L.latLng(lat / ring.length, lng / ring.length);
}

/* --- property helpers ------------------------------------- */
function _countryNameOf(f) {
    var p = f && f.properties; if (!p) return '';
    return p.name || p.NAME || p.ADMIN || p.name_en || '';
}
function _regionAdminOf(f) {
    var p = f && f.properties; if (!p) return '';
    return p.admin || p.ADMIN || '';
}
function _regionNameOf(f) {
    var p = f && f.properties; if (!p) return '';
    return p.name || p.NAME || p.name_en || '';
}

/* --- hide / show helpers ---------------------------------- */
function _hideAllCountries() {
    _allCountryLayers.forEach(function (l) {
        if (l !== _selCountryLayer) { map.removeLayer(l); l._hiddenBySel = true; }
    });
}
function _showAllCountries() {
    _allCountryLayers.forEach(function (l) {
        if (l._hiddenBySel) { l.addTo(map); l._hiddenBySel = false; }
    });
}
function _hideAllRegions(except) {
    _allRegionLayers.forEach(function (l) {
        if (l !== except) { map.removeLayer(l); l._hiddenBySel = true; }
    });
}
function _showAllRegions() {
    _allRegionLayers.forEach(function (l) {
        if (l._hiddenBySel) { l.addTo(map); l._hiddenBySel = false; }
    });
}

/* --- country select / deselect ---------------------------- */
function _selectCountry(layer, name) {
    if (_selCountryLayer === layer) { _deselectCountry(); return; }
    if (_selCountryLayer) _deselectCountry();

    _selCountryOrig = Object.assign({}, layer.options);
    _selCountryLayer = layer;
    _selCountryName = name;
    layer.setStyle({ color: '#ffdd00', weight: 8, opacity: 1, fillOpacity: 0.32, dashArray: '' });
    layer.bringToFront();
    _hideAllCountries();
    _startPulse(layer, { weight: 8, fillOpacity: 0.32 });
    $('#status-text').textContent = '📍 Selected: ' + name + ' — zoom in to see regions';
    _updateRegionVis();
}

function _deselectCountry() {
    if (!_selCountryLayer) return;
    _stopPulse();
    if (_selCountryOrig) _selCountryLayer.setStyle(_selCountryOrig);
    _selCountryLayer.bringToBack();
    _selCountryLayer = null; _selCountryName = null; _selCountryOrig = null;
    _hideRegions();
    _showAllCountries();
    $('#status-text').textContent = '🌍 Borders — hover to preview, double-click to select';
}

/* --- region select / deselect ----------------------------- */
function _selectRegion(layer, name) {
    if (_selRegionLayer === layer) { _deselectRegion(); return; }
    if (_selRegionLayer) _deselectRegion();
    _selRegionOrig = Object.assign({}, layer.options);
    _selRegionLayer = layer;
    layer.setStyle({ color: '#ff8800', weight: 8, opacity: 1, fillOpacity: 0.38, dashArray: '' });
    layer.bringToFront();
    _hideAllRegions(layer);
    _startPulse(layer, { weight: 8, fillOpacity: 0.38 });
    $('#status-text').textContent = '📍 Region: ' + name + ' (' + _selCountryName + ') — double-click again to deselect';
}

function _deselectRegion() {
    if (!_selRegionLayer) return;
    _stopPulse();
    if (_selRegionOrig) _selRegionLayer.setStyle(_selRegionOrig);
    _selRegionLayer.bringToBack();
    _selRegionLayer = null; _selRegionOrig = null;
    _showAllRegions();
}

/* --- fetch & build regions -------------------------------- */
function _fetchRegions() {
    if (_regionsData) { _buildRegionsLayer(); return; }
    if (_regionsLoading) return;
    _regionsLoading = true;
    fetch(REGIONS_GEOJSON_URL)
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(function (d) { _regionsData = d; _buildRegionsLayer(); })
        .catch(function (e) { console.error('Failed to load admin-1 regions:', e); })
        .finally(function () { _regionsLoading = false; });
}

function _buildRegionsLayer() {
    if (!_regionsData || !_selCountryName) return;
    _hideRegions();
    var cl = _selCountryName.toLowerCase();
    var feats = _regionsData.features.filter(function (f) {
        return _regionAdminOf(f).toLowerCase() === cl;
    });
    if (!feats.length) return;
    _regionsLayer = L.geoJSON({ type: 'FeatureCollection', features: feats }, {
        style: function () {
            return {
                color: 'rgba(255, 170, 70, 0.65)', weight: 2,
                fillColor: 'rgba(255, 170, 70, 0.12)', fillOpacity: 0.20,
                dashArray: '', renderer: canvasRenderer
            };
        },
        onEachFeature: function (feature, layer) {
            layer._isBorder = true;
            layer._isRegion = true;
            var rn = _regionNameOf(feature);
            if (rn) layer.bindTooltip(rn, { sticky: true, className: 'import-tooltip' });
            layer.on('mouseover', function (e) {
                if (_selRegionLayer === this) return;
                this.setStyle({ weight: 4, color: '#ffaa44', fillOpacity: 0.30, opacity: 1 });
                this.bringToFront();
                $('#status-text').textContent = '🗺️ ' + rn + ' (' + _selCountryName + ') — double-click to select';
            });
            layer.on('mouseout', function (e) {
                if (_selRegionLayer === this) return;
                _regionsLayer.resetStyle(this);
            });
            layer.on('dblclick', function (e) {
                if (e && e.originalEvent) L.DomEvent.stop(e.originalEvent);
                _selectRegion(this, rn);
            });
        }
    });
    _regionsLayer.addTo(map);
    _allRegionLayers = [];
    _regionsLayer.eachLayer(function (l) { _allRegionLayers.push(l); });
}

function _hideRegions() {
    if (_regionsLayer) { map.removeLayer(_regionsLayer); _regionsLayer = null; }
    _allRegionLayers = [];
    _deselectRegion();
}

/* --- zoom-based region visibility ------------------------- */
function _updateRegionVis() {
    var z = map.getZoom();
    if (_selCountryLayer && z >= REGION_MIN_ZOOM) {
        if (!_regionsLayer && !_regionsLoading) _fetchRegions();
    } else {
        if (_regionsLayer) _hideRegions();
    }
}
map.on('zoomend', _updateRegionVis);

/* --- main toggle ------------------------------------------ */
function toggleBorders() {
    var btn = $('#btn-borders');
    if (_bordersVisible && _bordersLayer) {
        _hideRegions();
        map.removeLayer(_bordersLayer);
        _bordersLayer = null; _bordersVisible = false;
        _allCountryLayers = [];
        _deselectCountry();
        btn.classList.remove('active');
        return;
    }
    if (_bordersLayer) {
        _bordersLayer.addTo(map);
        _bordersVisible = true;
        btn.classList.add('active');
        return;
    }
    if (_bordersLoading) return;
    _bordersLoading = true;
    btn.textContent = '⏳ Borders';
    btn.disabled = true;

    fetch(BORDERS_GEOJSON_URL)
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(function (data) {
            _bordersData = data;
            _bordersLayer = L.geoJSON(data, {
                style: function () {
                    return {
                        color: 'rgba(120, 180, 255, 0.7)', weight: 2.5,
                        fillColor: 'rgba(120, 180, 255, 0.08)', fillOpacity: 0.18,
                        dashArray: '', renderer: canvasRenderer
                    };
                },
                onEachFeature: function (feature, layer) {
                    layer._isBorder = true;
                    var cn = _countryNameOf(feature);
                    if (cn) layer.bindTooltip(cn, { sticky: true, className: 'import-tooltip' });
                    layer.on('mouseover', function (e) {
                        if (_selCountryLayer === this) return;
                        if (this._hiddenBySel) return;
                        this.setStyle({ weight: 5, color: '#78b4ff', fillOpacity: 0.22, opacity: 1 });
                        this.bringToFront();
                        $('#status-text').textContent = '🗺️ ' + cn + ' — click to select';
                    });
                    layer.on('mouseout', function (e) {
                        if (_selCountryLayer === this) return;
                        if (this._hiddenBySel) return;
                        _bordersLayer.resetStyle(this);
                    });
                    layer.on('click', function (e) {
                        if (_borderClickTimer) { clearTimeout(_borderClickTimer); _borderClickTimer = null; }
                        _borderClickTimer = setTimeout(function () {
                            _selectCountry(layer, cn);
                        }, 300);
                    });
                    layer.on('dblclick', function (e) {
                        if (_borderClickTimer) { clearTimeout(_borderClickTimer); _borderClickTimer = null; }
                        if (e && e.originalEvent) L.DomEvent.stop(e.originalEvent);
                        _selectCountry(this, cn);
                    });
                }
            });
            _bordersLayer.addTo(map);
            _bordersVisible = true;
            btn.classList.add('active');
            _allCountryLayers = [];
            _bordersLayer.eachLayer(function (l) { _allCountryLayers.push(l); });
        })
        .catch(function (err) {
            console.error('Failed to load country borders:', err);
            alert('Failed to load country borders.\n' + err.message);
        })
        .finally(function () {
            _bordersLoading = false;
            btn.textContent = '🌍 Borders';
            btn.disabled = false;
        });
}

$('#btn-borders').addEventListener('click', toggleBorders);

/* =====================================================
   Political Map overlay — colored fills + centroid labels
   =====================================================
   Works as a standalone overlay (bottom bar button)
   AND auto-loads when "🗺️ Political" base layer is selected.
   ===================================================== */
var _politicalData = null, _politicalLayer = null, _politicalLabelsLayer = null;
var _politicalLoading = false, _politicalVisible = false;

/* Palette: 24 distinct hues for dark-map readability */
var _POLITICAL_PALETTE = [
    '#3b82f6', '#ef4444', '#22c55e', '#eab308', '#a855f7',
    '#ec4899', '#14b8a6', '#f97316', '#06b6d4', '#8b5cf6',
    '#f43f5e', '#84cc16', '#0ea5e9', '#d946ef', '#f59e0b',
    '#10b981', '#6366f1', '#e11d48', '#65a30d', '#0891b2',
    '#7c3aed', '#fb923c', '#2dd4bf', '#c026d3'
];

function _politicalColor(name) {
    var h = 0;
    for (var i = 0; i < name.length; i++) { h = ((h << 5) - h + name.charCodeAt(i)) | 0; }
    return _POLITICAL_PALETTE[Math.abs(h) % _POLITICAL_PALETTE.length];
}

function _hexToRGBA(hex, alpha) {
    var r = parseInt(hex.slice(1, 3), 16);
    var g = parseInt(hex.slice(3, 5), 16);
    var b = parseInt(hex.slice(5, 7), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
}

function _labelFontSize(zoom) {
    if (zoom <= 2) return '0.55rem';
    if (zoom <= 3) return '0.65rem';
    if (zoom <= 4) return '0.78rem';
    if (zoom <= 5) return '0.9rem';
    return '1.05rem';
}

/* Load the GeoJSON + create layers (called once, then toggled) */
function _loadPoliticalOverlay() {
    if (_politicalLoading) return;
    _politicalLoading = true;
    var btn = $('#btn-political');
    btn.textContent = '⏳ Political';
    btn.disabled = true;

    var src = _bordersData ? Promise.resolve(_bordersData) :
        fetch(BORDERS_GEOJSON_URL).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); });

    src.then(function (data) {
        _politicalData = data;
        _politicalLabelsLayer = L.layerGroup();

        _politicalLayer = L.geoJSON(data, {
            style: function (feature) {
                var cn = _countryNameOf(feature);
                var c = _politicalColor(cn);
                return {
                    color: '#ffffff', weight: 1.2, opacity: 0.55,
                    fillColor: _hexToRGBA(c, 0.35), fillOpacity: 0.35,
                    dashArray: '', renderer: canvasRenderer
                };
            },
            onEachFeature: function (feature, layer) {
                layer._isPolitical = true;
                var cn = _countryNameOf(feature);
                if (cn) layer.bindTooltip(cn, { sticky: true, className: 'import-tooltip' });
                var c = _politicalColor(cn);
                layer.on('mouseover', function (e) {
                    this.setStyle({ weight: 2.5, color: '#ffffff', opacity: 0.9,
                        fillColor: _hexToRGBA(c, 0.55), fillOpacity: 0.55 });
                    this.bringToFront();
                    $('#status-text').textContent = '🗺️ ' + cn;
                });
                layer.on('mouseout', function (e) {
                    _politicalLayer.resetStyle(this);
                });
                /* Permanent centroid label */
                try {
                    var centroid = _polygonCentroid(layer);
                    var fs = _labelFontSize(map.getZoom());
                    var label = L.marker(centroid, {
                        icon: L.divIcon({
                            className: 'political-label',
                            html: '<span style="font-size:' + fs + '">' + cn + '</span>',
                            iconSize: [0, 0],
                            iconAnchor: [0, 0]
                        }),
                        interactive: false
                    });
                    _politicalLabelsLayer.addLayer(label);
                } catch (_) {}
            }
        });

        _politicalLayer.addTo(map);
        _politicalLabelsLayer.addTo(map);
        _politicalVisible = true;
        btn.classList.add('active');
        btn.textContent = '🗺️ Political';
        btn.disabled = false;
        $('#status-text').textContent = '🗺️ Political map — colored countries with labels';
    })
    .catch(function (err) {
        console.error('Failed to load political map:', err);
        alert('Failed to load political map.\n' + err.message);
        _politicalLoading = false;
        btn.textContent = '🗺️ Political';
        btn.disabled = false;
    });
}

function togglePolitical() {
    var btn = $('#btn-political');
    if (_politicalVisible && _politicalLayer) {
        map.removeLayer(_politicalLayer);
        if (_politicalLabelsLayer) map.removeLayer(_politicalLabelsLayer);
        _politicalLayer = null; _politicalVisible = false;
        _politicalLabelsLayer = null;
        btn.classList.remove('active');
        $('#status-text').textContent = 'Political map hidden';
        return;
    }
    if (_politicalLayer) {
        _politicalLayer.addTo(map);
        if (_politicalLabelsLayer) _politicalLabelsLayer.addTo(map);
        _politicalVisible = true;
        btn.classList.add('active');
        $('#status-text').textContent = '🗺️ Political map — colored countries with labels';
        return;
    }
    _loadPoliticalOverlay();
}

$('#btn-political').addEventListener('click', togglePolitical);

/* =====================================================
   Rivers Overlay — fetches Natural Earth rivers GeoJSON
   ===================================================== */
var RIVERS_URL = 'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_rivers_lake_centerlines.geojson';

function toggleRivers() {
    if (S._riversVisible && S._riversLayer) {
        map.removeLayer(S._riversLayer);
        S._riversLayer = null; S._riversVisible = false;
        $('#btn-rivers').classList.remove('active');
        $('#status-text').textContent = 'Rivers hidden';
        return;
    }
    if (S._riversLayer) {
        S._riversLayer.addTo(map);
        S._riversVisible = true;
        $('#btn-rivers').classList.add('active');
        $('#status-text').textContent = '🌊 Rivers — hover to see name';
        return;
    }
    if (S._riversLoading) return;
    S._riversLoading = true;
    var btn = $('#btn-rivers');
    btn.textContent = '⏳ Rivers'; btn.disabled = true;

    fetch(RIVERS_URL)
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(function (data) {
            S._riversData = data;
            S._riversLayer = L.geoJSON(data, {
                style: function (feature) {
                    var sc = feature && feature.properties ? (feature.properties.scalerank || 5) : 5;
                    var w = sc <= 2 ? 2.5 : sc <= 4 ? 1.8 : 1.3;
                    var o = sc <= 2 ? 0.85 : sc <= 4 ? 0.70 : 0.55;
                    return {
                        color: 'rgba(80, 160, 255, ' + o + ')',
                        weight: w, opacity: 1,
                        lineCap: 'round', lineJoin: 'round',
                        renderer: canvasRenderer
                    };
                },
                onEachFeature: function (feature, layer) {
                    var rn = feature && feature.properties ? (feature.properties.name || '') : '';
                    if (rn) layer.bindTooltip(rn, { sticky: true, className: 'import-tooltip' });
                    layer.on('mouseover', function () {
                        var sc = feature && feature.properties ? (feature.properties.scalerank || 5) : 5;
                        var bw = sc <= 2 ? 4 : sc <= 4 ? 3 : 2.5;
                        this.setStyle({ weight: bw, color: 'rgba(100, 220, 255, 0.95)' });
                        this.bringToFront();
                        $('#status-text').textContent = '🌊 ' + (rn || 'River');
                    });
                    layer.on('mouseout', function () {
                        S._riversLayer.resetStyle(this);
                    });
                }
            });
            S._riversLayer.addTo(map);
            S._riversVisible = true;
            btn.classList.add('active');
            $('#status-text').textContent = '🌊 Rivers — hover to see name';
        })
        .catch(function (err) {
            console.error('Failed to load rivers:', err);
            alert('Failed to load rivers.\n' + err.message);
        })
        .finally(function () {
            S._riversLoading = false;
            btn.textContent = '🌊 Rivers'; btn.disabled = false;
        });
}

$('#btn-rivers').addEventListener('click', toggleRivers);

/* =====================================================
   NATO Member Countries Overlay
   ===================================================== */
var _natoMembers = [
    'Albania', 'Belgium', 'Bulgaria', 'Canada', 'Croatia',
    'Czech Republic', 'Denmark', 'Estonia', 'Finland', 'France',
    'Germany', 'Greece', 'Hungary', 'Iceland', 'Italy',
    'Latvia', 'Lithuania', 'Luxembourg', 'Montenegro', 'Netherlands',
    'Macedonia', 'Norway', 'Poland', 'Portugal', 'Romania',
    'Slovakia', 'Slovenia', 'Spain', 'Sweden', 'Turkey',
    'England', 'USA'
];
var _natoLayer = null, _natoLabelsLayer = null, _natoVisible = false, _natoLoading = false;

function _natoColor() { return '#3b82f6'; }

function _isNatoMember(name) {
    if (!name) return false;
    var n = name.toLowerCase();
    return _natoMembers.some(function (m) { return m.toLowerCase() === n; });
}

function _loadNatoOverlay() {
    if (_natoLoading) return;
    _natoLoading = true;
    var btn = $('#btn-nato');
    btn.textContent = '⏳ NATO'; btn.disabled = true;

    var src = _bordersData ? Promise.resolve(_bordersData) :
        fetch(BORDERS_GEOJSON_URL).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); });

    src.then(function (data) {
        _natoLabelsLayer = L.layerGroup();
        var filtered = {
            type: 'FeatureCollection',
            features: data.features.filter(function (f) {
                return _isNatoMember(_countryNameOf(f));
            })
        };
        _natoLayer = L.geoJSON(filtered, {
            style: function () {
                return {
                    color: '#60a5fa', weight: 6, opacity: 0.85,
                    fillColor: 'rgba(59,130,246,0.30)', fillOpacity: 0.30,
                    dashArray: '', renderer: canvasRenderer
                };
            },
            onEachFeature: function (feature, layer) {
                var cn = _countryNameOf(feature);
                if (cn) layer.bindTooltip(cn, { sticky: true, className: 'import-tooltip' });
                layer.on('mouseover', function (e) {
                    this.setStyle({ weight: 3.5, color: '#93c5fd', fillOpacity: 0.45, opacity: 1 });
                    this.bringToFront();
                    $('#status-text').textContent = '🛡️ NATO — ' + cn;
                });
                layer.on('mouseout', function (e) {
                    _natoLayer.resetStyle(this);
                });
                try {
                    var centroid = _polygonCentroid(layer);
                    var fs = _labelFontSize(map.getZoom());
                    var label = L.marker(centroid, {
                        icon: L.divIcon({
                            className: 'political-label',
                            html: '<span style="font-size:' + fs + ';color:#93c5fd">🛡️ ' + cn + '</span>',
                            iconSize: [0, 0], iconAnchor: [0, 0]
                        }),
                        interactive: false
                    });
                    _natoLabelsLayer.addLayer(label);
                } catch (_) {}
            }
        });
        _natoLoading = false;
        _natoLayer.addTo(map);
        _natoLabelsLayer.addTo(map);
        _natoVisible = true;
        btn.classList.add('active');
        btn.textContent = '🛡️ NATO'; btn.disabled = false;
        $('#status-text').textContent = '🛡️ NATO member countries (' + filtered.features.length + ' members)';
    })
    .catch(function (err) {
        console.error('Failed to load NATO overlay:', err);
        alert('Failed to load NATO overlay.\n' + err.message);
        _natoLoading = false;
        btn.textContent = '🛡️ NATO'; btn.disabled = false;
    });
}

function toggleNato() {
    var btn = $('#btn-nato');
    if (_natoVisible && _natoLayer) {
        map.removeLayer(_natoLayer);
        if (_natoLabelsLayer) map.removeLayer(_natoLabelsLayer);
        _natoLayer = null; _natoVisible = false;
        _natoLabelsLayer = null;
        btn.classList.remove('active');
        $('#status-text').textContent = 'NATO overlay hidden';
        return;
    }
    if (_natoLayer) {
        _natoLayer.addTo(map);
        if (_natoLabelsLayer) _natoLabelsLayer.addTo(map);
        _natoVisible = true;
        btn.classList.add('active');
        $('#status-text').textContent = '🛡️ NATO member countries';
        return;
    }
    _loadNatoOverlay();
}

$('#btn-nato').addEventListener('click', toggleNato);

/* =====================================================
   EU Member Countries Overlay
   ===================================================== */
var _euMembers = [
    'Austria', 'Belgium', 'Bulgaria', 'Croatia', 'Cyprus',
    'Czech Republic', 'Denmark', 'Estonia', 'Finland', 'France',
    'Germany', 'Greece', 'Hungary', 'Ireland', 'Italy',
    'Latvia', 'Lithuania', 'Luxembourg', 'Malta', 'Netherlands',
    'Poland', 'Portugal', 'Romania', 'Slovakia', 'Slovenia',
    'Spain', 'Sweden'
];
var _euLayer = null, _euLabelsLayer = null, _euVisible = false, _euLoading = false;

function _euColor() { return '#fbbf24'; }

function _isEuMember(name) {
    if (!name) return false;
    var n = name.toLowerCase();
    return _euMembers.some(function (m) { return m.toLowerCase() === n; });
}

function _loadEuOverlay() {
    if (_euLoading) return;
    _euLoading = true;
    var btn = $('#btn-eu');
    btn.textContent = '⏳ EU'; btn.disabled = true;

    var src = _bordersData ? Promise.resolve(_bordersData) :
        fetch(BORDERS_GEOJSON_URL).then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); });

    src.then(function (data) {
        _euLabelsLayer = L.layerGroup();
        var filtered = {
            type: 'FeatureCollection',
            features: data.features.filter(function (f) {
                return _isEuMember(_countryNameOf(f));
            })
        };
        _euLayer = L.geoJSON(filtered, {
            style: function () {
                return {
                    color: '#f59e0b', weight: 6, opacity: 0.85,
                    fillColor: 'rgba(251,191,36,0.25)', fillOpacity: 0.25,
                    dashArray: '', renderer: canvasRenderer
                };
            },
            onEachFeature: function (feature, layer) {
                var cn = _countryNameOf(feature);
                if (cn) layer.bindTooltip(cn, { sticky: true, className: 'import-tooltip' });
                layer.on('mouseover', function (e) {
                    this.setStyle({ weight: 3.5, color: '#fcd34d', fillOpacity: 0.40, opacity: 1 });
                    this.bringToFront();
                    $('#status-text').textContent = '🇪🇺 EU — ' + cn;
                });
                layer.on('mouseout', function (e) {
                    _euLayer.resetStyle(this);
                });
                try {
                    var centroid = _polygonCentroid(layer);
                    var fs = _labelFontSize(map.getZoom());
                    var label = L.marker(centroid, {
                        icon: L.divIcon({
                            className: 'political-label',
                            html: '<span style="font-size:' + fs + ';color:#fcd34d">🇪🇺 ' + cn + '</span>',
                            iconSize: [0, 0], iconAnchor: [0, 0]
                        }),
                        interactive: false
                    });
                    _euLabelsLayer.addLayer(label);
                } catch (_) {}
            }
        });
        _euLoading = false;
        _euLayer.addTo(map);
        _euLabelsLayer.addTo(map);
        _euVisible = true;
        btn.classList.add('active');
        btn.textContent = '🇪🇺 EU'; btn.disabled = false;
        $('#status-text').textContent = '🇪🇺 EU member countries (' + filtered.features.length + ' members)';
    })
    .catch(function (err) {
        console.error('Failed to load EU overlay:', err);
        alert('Failed to load EU overlay.\n' + err.message);
        _euLoading = false;
        btn.textContent = '🇪🇺 EU'; btn.disabled = false;
    });
}

function toggleEu() {
    var btn = $('#btn-eu');
    if (_euVisible && _euLayer) {
        map.removeLayer(_euLayer);
        if (_euLabelsLayer) map.removeLayer(_euLabelsLayer);
        _euLayer = null; _euVisible = false;
        _euLabelsLayer = null;
        btn.classList.remove('active');
        $('#status-text').textContent = 'EU overlay hidden';
        return;
    }
    if (_euLayer) {
        _euLayer.addTo(map);
        if (_euLabelsLayer) _euLabelsLayer.addTo(map);
        _euVisible = true;
        btn.classList.add('active');
        $('#status-text').textContent = '🇪🇺 EU member countries';
        return;
    }
    _loadEuOverlay();
}

$('#btn-eu').addEventListener('click', toggleEu);

/* =====================================================
   Tool Management
   ===================================================== */
function setTool(tool) {
    /* finish any in-progress drawing */
    if (S.tool === 'freehand' && S.drawing) finishFreehand();
    if (S.tool === 'arrow' && S.arrowDrawing) finishArrow();
    if (S.tool === 'measure' && S.msPoints.length > 0) finishMeasure();

    /* hide label input if switching away */
    if (S.tool === 'label') hideLabelInput();

    /* leave previous tool */
    if (S.tool === 'eraser') disableEraser();

    S.tool = tool;
    S.drawing = false;

    /* map dragging — disabled for eraser so drag-to-erase works */
    if (tool === 'pan') map.dragging.enable();
    else map.dragging.disable();

    /* enter new tool */
    if (tool === 'eraser') enableEraser();

    /* UI */
    $$('.tool-btn').forEach(b => b.classList.toggle('active', b.dataset.tool === tool));
    $('#status-text').textContent = STATUS[tool];
    const icons = {
        pan: '\u{1F4CD}', freehand: '\u270F\uFE0F',
        arrow: '\u27A1\uFE0F', marker: '\u{1F4CC}', label: '\u{1F3F7}\uFE0F', measure: '\u{1F4CF}', eraser: '\u{1F9F9}',
        fire: '\u{1F525}'
    };
    $('#status-icon').textContent = icons[tool] || '\u{1F4CD}';
    Array.from(document.body.classList)
        .filter(className => className.indexOf('tool-') === 0)
        .forEach(className => document.body.classList.remove(className));
    document.body.classList.add('tool-' + tool);
    if (tool !== 'measure') $('#btn-finish').classList.add('hidden');
    /* show/hide flag panel when arrow tool is active */
    const flagPanel = $('#flag-panel');
    if (flagPanel) flagPanel.classList.toggle('hidden', tool !== 'arrow');
    updateUndoRedoUI();
}

/* =====================================================
   Freehand Drawing
   ===================================================== */
function startFreehand(e) {
    if (S.tool !== 'freehand') return;
    S.drawing = true;
    S.fhPoints = [[e.latlng.lat, e.latlng.lng]];
    S.fhLine = L.polyline(S.fhPoints, {
        color: S.color, weight: S.weight,
        dashArray: DASH[S.dashStyle], opacity: 1,
        lineCap: 'round', lineJoin: 'round',
        smoothFactor: 1.5
    }).addTo(map);
}

function moveFreehand(e) {
    if (!S.drawing || !S.fhLine) return;
    S.lastLatLng = e.latlng;
    S.fhPoints.push([e.latlng.lat, e.latlng.lng]);
    S.fhLine.addLatLng(e.latlng);
}

function finishFreehand() {
    if (!S.fhLine) { resetFreehand(); return; }
    if (S.fhPoints.length < 2) {
        map.removeLayer(S.fhLine);
        resetFreehand();
        return;
    }
    /* smooth the freehand stroke */
    const simplified = rdpSimplify(S.fhPoints, 0.00005);
    const smoothed = simplified.length >= 3
        ? catmullRom(simplified, 8) : simplified;
    S.fhLine.setLatLngs(smoothed);
    storeAnnotation(S.fhLine, 'freehand', smoothed);
    resetFreehand();
}

function resetFreehand() {
    S.fhPoints = []; S.fhLine = null; S.drawing = false;
}

/* =====================================================
   Arrow Drawing (click-and-drag)
   ===================================================== */
function computeArrowAngle(startLatLng, endLatLng) {
    var dLng = (endLatLng.lng - startLatLng.lng) * Math.PI / 180;
    var lat1 = startLatLng.lat * Math.PI / 180;
    var lat2 = endLatLng.lat * Math.PI / 180;
    var y = Math.sin(dLng) * Math.cos(lat2);
    var x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
    return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}

/* ── Emoji → Twemoji SVG img ─────────────────────────── */
var TWEMOJI_BASE = 'https://cdn.jsdelivr.net/gh/twitter/twemoji@14.0.2/assets/svg/';
function emojiToCodePoint(str) {
    var codes = [];
    for (var i = 0; i < str.length; i++) {
        var cp = str.codePointAt(i);
        if (cp > 0xFFFF) i++; /* skip surrogate pair */
        codes.push(cp.toString(16));
    }
    return codes.join('-');
}
function flagEmojiToImgHtml(emoji) {
    return '<img src="' + TWEMOJI_BASE + emojiToCodePoint(emoji) + '.svg" draggable="false" alt="' + emoji + '">';
}

function createArrowheadIcon(color, preview, flag) {
    var size = 24;
    var svgNs = 'http://www.w3.org/2000/svg';
    var flagHtml = flag
        ? '<span class="arrowhead-flag">' + flagEmojiToImgHtml(flag) + '</span>'
        : '';
    return L.divIcon({
        className: '',
        html: '<div class="arrowhead-wrap' + (preview ? ' arrowhead-preview' : '') + '">'
            + '<svg xmlns="' + svgNs + '" width="' + size + '" height="' + size + '" viewBox="0 0 24 24">'
            + '<polygon points="12,1 22,22 12,17 2,22" fill="' + color + '" '
            + 'stroke="rgba(255,255,255,0.45)" stroke-width="1.2" stroke-linejoin="round"/>'
            + '</svg>' + flagHtml + '</div>',
        iconSize: [size, size],
        iconAnchor: [size / 2, size / 2]
    });
}

function removeArrowHead(ann) {
    if (ann && ann.extra && ann.extra.headLayer) {
        map.removeLayer(ann.extra.headLayer);
    }
}

function addArrowHeadToAnnotation(ann, marker) {
    if (!ann || !marker) return;
    marker._arrowId = ann.id;
    marker._isArrowHead = true;
    ann.extra = ann.extra || {};
    ann.extra.headLayer = marker;
}

function startArrow(e) {
    if (S.tool !== 'arrow') return;
    S.arrowDrawing = true;
    S.arrowStart = e.latlng;
    S.arrowLine = L.polyline([e.latlng, e.latlng], {
        color: S.color, weight: S.weight,
        dashArray: DASH[S.dashStyle], opacity: 1,
        lineCap: 'round', lineJoin: 'round'
    }).addTo(map);
    S.arrowHead = L.marker(e.latlng, {
        icon: createArrowheadIcon(S.color, true, S.flag),
        interactive: false
    }).addTo(map);
}

function moveArrow(e) {
    if (!S.arrowDrawing || !S.arrowLine) return;
    S.lastLatLng = e.latlng;
    S.arrowLine.setLatLngs([S.arrowStart, e.latlng]);
    S.arrowHead.setLatLng(e.latlng);
    var angle = computeArrowAngle(S.arrowStart, e.latlng);
    var el = S.arrowHead.getElement();
    if (el) {
        var inner = el.querySelector('.arrowhead-wrap');
        if (inner) inner.style.transform = 'rotate(' + angle + 'deg)';
        var flagEl = el.querySelector('.arrowhead-flag');
        if (flagEl) flagEl.style.transform = 'translateY(-50%) rotate(' + (-angle) + 'deg)';
    }
}

function finishArrow() {
    if (!S.arrowLine || !S.arrowStart) { resetArrow(); return; }
    if (S.arrowHead) { map.removeLayer(S.arrowHead); S.arrowHead = null; }
    var latlngs = S.arrowLine.getLatLngs();
    if (latlngs.length < 2 || (latlngs[0].lat === latlngs[1].lat && latlngs[0].lng === latlngs[1].lng)) {
        map.removeLayer(S.arrowLine); resetArrow(); return;
    }
    var startLL = latlngs[0], endLL = latlngs[1];
    var angle = computeArrowAngle(startLL, endLL);
    var coords = [[startLL.lat, startLL.lng], [endLL.lat, endLL.lng]];
    var currentFlag = S.flag;
    var headIcon = createArrowheadIcon(S.color, false, currentFlag);
    /* Keep the head visual-only so the line receives eraser clicks at its end. */
    var headMarker = L.marker(endLL, { icon: headIcon, interactive: false }).addTo(map);
    var headEl = headMarker.getElement();
    if (headEl) {
        var inner = headEl.querySelector('.arrowhead-wrap');
        if (inner) inner.style.transform = 'rotate(' + angle + 'deg)';
        var flagEl = headEl.querySelector('.arrowhead-flag');
        if (flagEl) flagEl.style.transform = 'translateY(-50%) rotate(' + (-angle) + 'deg)';
    }
    storeAnnotation(S.arrowLine, 'arrow', coords, { headLatLng: [endLL.lat, endLL.lng], angle: angle, flag: currentFlag || null });
    addArrowHeadToAnnotation(S.annotations[S.annotations.length - 1], headMarker);
    resetArrow();
}

function resetArrow() {
    S.arrowStart = null; S.arrowLine = null; S.arrowHead = null; S.arrowDrawing = false;
}

/* =====================================================
   Marker / Pin Tool
   ===================================================== */
function placeMarker(e) {
    if (S.tool !== 'marker') return;
    const icon = L.divIcon({
        className: '',
        html: '<div class="marker-pin" style="background:' + S.color + '"></div>',
        iconSize: [18, 22], iconAnchor: [9, 22]
    });
    const marker = L.marker(e.latlng, { icon }).addTo(map);
    storeAnnotation(marker, 'marker', [e.latlng.lat, e.latlng.lng]);
}

/* =====================================================
   Text Label Tool
   ===================================================== */
const labelWrap   = $('#label-input-wrap');
const labelInput  = $('#label-text-input');
const labelOkBtn  = $('#label-ok');
const labelCancelBtn = $('#label-cancel');

function showLabelInput(latlng, screenPt) {
    S.labelLatLng = latlng;
    labelWrap.style.left = screenPt.x + 'px';
    labelWrap.style.top  = (screenPt.y - 50) + 'px';
    labelWrap.classList.remove('hidden');
    labelInput.value = '';
    labelInput.focus();
}
function hideLabelInput() { labelWrap.classList.add('hidden'); S.labelLatLng = null; }

function placeLabel() {
    const text = labelInput.value.trim();
    if (!text || !S.labelLatLng) { hideLabelInput(); return; }
    const icon = L.divIcon({
        className: '',
        html: '<div class="label-marker" style="border-color:' + S.color + ';color:#ffffff">' + escapeHtml(text) + '</div>',
        iconSize: null, iconAnchor: [0, 0]
    });
    const m = L.marker(S.labelLatLng, { icon, interactive: true }).addTo(map);
    storeAnnotation(m, 'label', [S.labelLatLng.lat, S.labelLatLng.lng], { text });
    hideLabelInput();
}

/* =====================================================
   Fire Emoji Tool
   ===================================================== */
function placeFire(e) {
    if (S.tool !== 'fire') return;
    const icon = L.divIcon({
        className: '',
        html: '<div class="fire-marker">🔥</div>',
        iconSize: [32, 32], iconAnchor: [16, 16]
    });
    const marker = L.marker(e.latlng, { icon }).addTo(map);
    storeAnnotation(marker, 'fire', [e.latlng.lat, e.latlng.lng]);
}
function escapeHtml(s) {
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

labelOkBtn.addEventListener('click', placeLabel);
labelCancelBtn.addEventListener('click', hideLabelInput);
labelInput.addEventListener('keydown', e => {
    if (e.key === 'Enter')  { e.preventDefault(); placeLabel(); }
    if (e.key === 'Escape') { e.preventDefault(); hideLabelInput(); }
    e.stopPropagation();
});

/* =====================================================
   Distance Measurement Tool
   ===================================================== */
function startMeasure(e) {
    if (S.tool !== 'measure') return;
    S.msPoints.push(e.latlng);
    if (!S.msLine) {
        S.msLine = L.polyline(S.msPoints, {
            color: '#00ddff', weight: 2, dashArray: '8, 6', opacity: 0.9
        }).addTo(map);
    } else { S.msLine.addLatLng(e.latlng); }
    if (S.msPoints.length >= 2) $('#btn-finish').classList.remove('hidden');
    updateMeasureLabels();
    updateMeasurePreview(e);
}

function updateMeasurePreview(e) {
    if (S.msPoints.length === 0) return;
    const last = S.msPoints[S.msPoints.length - 1];
    if (!S.msPreview) {
        S.msPreview = L.polyline([last, e.latlng], {
            color: '#00ddff', weight: 1, dashArray: '4, 8', opacity: 0.5, interactive: false
        }).addTo(map);
    } else { S.msPreview.setLatLngs([last, e.latlng]); }
}

function moveMeasurePreview(e) {
    if (S.tool === 'measure' && S.msPoints.length > 0) updateMeasurePreview(e);
}

function updateMeasureLabels() {
    S.msLabels.forEach(l => map.removeLayer(l));
    S.msLabels = [];
    let total = 0;
    for (let i = 1; i < S.msPoints.length; i++) {
        const seg = S.msPoints[i - 1].distanceTo(S.msPoints[i]);
        total += seg;
        const mid = L.latLng(
            (S.msPoints[i - 1].lat + S.msPoints[i].lat) / 2,
            (S.msPoints[i - 1].lng + S.msPoints[i].lng) / 2
        );
        const lbl = L.tooltip({ permanent: true, direction: 'center', className: 'measure-label', interactive: false })
            .setContent(fmtDist(seg)).setLatLng(mid).addTo(map);
        S.msLabels.push(lbl);
    }
    if (S.msPoints.length >= 2) {
        const last = S.msPoints[S.msPoints.length - 1];
        const totalLbl = L.tooltip({ permanent: true, direction: 'top', offset: [0, -10],
            className: 'measure-label measure-total', interactive: false })
            .setContent('\u2248 ' + fmtDist(total)).setLatLng(last).addTo(map);
        S.msLabels.push(totalLbl);
    }
    if (S.msPoints.length >= 2) $('#status-text').textContent = 'Distance: ' + fmtDist(total) + ' (Enter to finish)';
}

function fmtDist(m) { return m >= 1000 ? (m / 1000).toFixed(2) + ' km' : m.toFixed(0) + ' m'; }

function finishMeasure() {
    if (S.msPreview) { map.removeLayer(S.msPreview); S.msPreview = null; }
    S.msLabels.forEach(l => map.removeLayer(l)); S.msLabels = [];
    if (S.msPoints.length < 2 || !S.msLine) { cancelMeasure(); return; }
    let total = 0;
    for (let i = 1; i < S.msPoints.length; i++) total += S.msPoints[i - 1].distanceTo(S.msPoints[i]);
    const last = S.msPoints[S.msPoints.length - 1];
    const totalLbl = L.tooltip({ permanent: true, direction: 'top', offset: [0, -10],
        className: 'measure-label measure-total', interactive: false })
        .setContent('\u2248 ' + fmtDist(total)).setLatLng(last).addTo(map);
    S.msLine._totalLabel = totalLbl;
    storeAnnotation(S.msLine, 'measure', S.msPoints.map(p => [p.lat, p.lng]), { total });
    S.msPoints = []; S.msLine = null; S.msPreview = null;
    $('#btn-finish').classList.add('hidden');
}

function cancelMeasure() {
    if (S.msPreview) map.removeLayer(S.msPreview);
    S.msLabels.forEach(l => map.removeLayer(l));
    if (S.msLine) map.removeLayer(S.msLine);
    S.msPoints = []; S.msLine = null; S.msLabels = []; S.msPreview = null;
    $('#btn-finish').classList.add('hidden');
}

/* =====================================================
   Eraser
   ===================================================== */
function enableEraser() {
    S.annotations.forEach(ann => {
        if (ann.locked) return; /* skip locked annotations */
        const isPoint = ann.type === 'marker' || ann.type === 'label' || ann.type === 'fire';
        const origWeight = ann.weight;
        /* Force interactive mode so eraser can receive clicks (measurement lines are non-interactive by default) */
        if (ann.layer && ann.layer.options) {
            ann._origInteractive = ann.layer.options.interactive;
            ann.layer.options.interactive = true;
            if (ann.layer.getElement) {
                const el = ann.layer.getElement();
                if (el) el.style.pointerEvents = 'auto';
            }
        }
        /* Make lines thicker for easier clicking during erase mode */
        if (!isPoint && ann.layer && ann.layer.setStyle) {
            ann.layer.setStyle({ weight: Math.max(8, origWeight + 5) });
            ann.layer.bringToFront();
        }
        const h = {
            over: function () {
                if (isPoint) {
                    const el = this.getElement();
                    if (el) { const inner = el.querySelector('.marker-pin, .label-marker, .fire-marker'); if (inner) inner.classList.add('eraser-hover'); }
                } else if (this.setStyle) {
                    this.setStyle({ color: '#ff4444', weight: Math.max(10, origWeight + 6) });
                    this.bringToFront();
                }
            },
            out: function () {
                if (isPoint) {
                    const el = this.getElement();
                    if (el) { const inner = el.querySelector('.marker-pin, .label-marker, .fire-marker'); if (inner) inner.classList.remove('eraser-hover'); }
                } else if (this.setStyle) {
                    this.setStyle({ color: ann.color, weight: Math.max(8, origWeight + 5) });
                }
            },
            click: function (ev) {
                if (ev && ev.originalEvent) L.DomEvent.stop(ev.originalEvent);
                removeAnnotation(ann.id);
            }
        };
        ann.layer.on('mouseover', h.over);
        ann.layer.on('mouseout', h.out);
        ann.layer.on('click', h.click);
        S.eraserHandlers.push({ ann, h });
    });
}

function disableEraser() {
    S.eraserHandlers.forEach(({ ann, h }) => {
        restoreEraserState(ann, h);
    });
    S.eraserHandlers = [];
}

function restoreEraserState(ann, h) {
    if (!ann || !ann.layer) return;
    ann.layer.off('mouseover', h.over);
    ann.layer.off('mouseout', h.out);
    ann.layer.off('click', h.click);
    /* Restore original style (weight, color) that was changed for eraser visibility */
    const isPoint = ann.type === 'marker' || ann.type === 'label' || ann.type === 'fire';
    if (isPoint && ann.layer.getElement) {
        const el = ann.layer.getElement();
        if (el) {
            const inner = el.querySelector('.marker-pin, .label-marker, .fire-marker');
            if (inner) inner.classList.remove('eraser-hover');
        }
    }
    if (!isPoint && ann.layer.setStyle) {
        ann.layer.setStyle({ weight: ann.weight, color: ann.color });
        ann.layer.bringToBack();
    }
    /* Restore original interactive state */
    if (ann.layer.options && ann._origInteractive !== undefined) {
        ann.layer.options.interactive = ann._origInteractive;
        if (ann.layer.getElement) {
            const el = ann.layer.getElement();
            if (el) el.style.pointerEvents = '';
        }
        delete ann._origInteractive;
    }
}

function removeEraserHandlersFor(ann) {
    S.eraserHandlers = S.eraserHandlers.filter(({ ann: current, h }) => {
        if (current !== ann) return true;
        restoreEraserState(ann, h);
        return false;
    });
}

/* ── Eraser drag-to-erase ──────────────────────── */
const ERASE_RADIUS_PX = 25;

function eraserDragStart() {
    if (S.tool !== 'eraser') return;
    S.eraserDragging = true;
    S.eraserErasedIds = new Set();
}

function eraserDragMove(e) {
    if (!S.eraserDragging || S.tool !== 'eraser') return;
    var containerPoint = map.latLngToContainerPoint(e.latlng);
    S.annotations.slice().forEach(function (ann) {
        if (S.eraserErasedIds.has(ann.id)) return;
        if (ann.locked) return; /* skip locked annotations */
        var hit = false;
        var isPoint = ann.type === 'marker' || ann.type === 'label' || ann.type === 'fire';
        if (isPoint) {
            /* For point annotations, check distance from cursor to the annotation's latlng */
            var annLatLng = ann.coords;
            if (Array.isArray(annLatLng) && annLatLng.length === 2) {
                var annPoint = map.latLngToContainerPoint(L.latLng(annLatLng[0], annLatLng[1]));
                var dist = Math.hypot(containerPoint.x - annPoint.x, containerPoint.y - annPoint.y);
                if (dist <= ERASE_RADIUS_PX) hit = true;
            }
        } else {
            /* For line annotations, check distance from cursor to each segment */
            var coords = ann.coords;
            if (Array.isArray(coords)) {
                for (var i = 0; i < coords.length - 1; i++) {
                    var p1 = map.latLngToContainerPoint(L.latLng(coords[i][0], coords[i][1]));
                    var p2 = map.latLngToContainerPoint(L.latLng(coords[i + 1][0], coords[i + 1][1]));
                    var d = pointToSegmentDist(containerPoint.x, containerPoint.y, p1.x, p1.y, p2.x, p2.y);
                    if (d <= ERASE_RADIUS_PX) { hit = true; break; }
                }
            }
        }
        if (hit) {
            S.eraserErasedIds.add(ann.id);
            removeAnnotation(ann.id);
        }
    });
}

function eraserDragEnd() {
    S.eraserDragging = false;
    S.eraserErasedIds = new Set();
}

/* Helper: distance from point (px,py) to segment (ax,ay)-(bx,by) */
function pointToSegmentDist(px, py, ax, ay, bx, by) {
    var dx = bx - ax, dy = by - ay;
    var lenSq = dx * dx + dy * dy;
    if (lenSq === 0) return Math.hypot(px - ax, py - ay);
    var t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / lenSq));
    return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}

/* =====================================================
   Undo / Redo
   ===================================================== */
function pushUndo(action) {
    S.undoStack.push(action);
    if (S.undoStack.length > UNDO_LIMIT) S.undoStack.shift();
    S.redoStack = [];
    updateUndoRedoUI();
}

function undo() {
    if (S.undoStack.length === 0) return;
    const a = S.undoStack.pop();
    if (a.type === 'add') {
        map.removeLayer(a.ann.layer);
        removeArrowHead(a.ann);
        S.annotations = S.annotations.filter(x => x.id !== a.ann.id);
    } else if (a.type === 'remove') {
        a.ann.layer.addTo(map);
        if (a.ann.extra && a.ann.extra.headLayer) a.ann.extra.headLayer.addTo(map);
        if (a.ann.layer._totalLabel) a.ann.layer._totalLabel.addTo(map);
        S.annotations.push(a.ann);
    } else if (a.type === 'clear') {
        a.anns.forEach(x => {
            x.layer.addTo(map);
            if (x.extra && x.extra.headLayer) x.extra.headLayer.addTo(map);
            if (x.layer._totalLabel) x.layer._totalLabel.addTo(map);
            S.annotations.push(x);
        });
    }
    if (S.tool === 'eraser') { disableEraser(); enableEraser(); }
    S.redoStack.push(a);
    updateCount(); updateUndoRedoUI();
}

function redo() {
    if (S.redoStack.length === 0) return;
    const a = S.redoStack.pop();
    if (a.type === 'add') {
        a.ann.layer.addTo(map);
        if (a.ann.extra && a.ann.extra.headLayer) a.ann.extra.headLayer.addTo(map);
        S.annotations.push(a.ann);
    } else if (a.type === 'remove') {
        map.removeLayer(a.ann.layer);
        removeArrowHead(a.ann);
        if (a.ann.layer._totalLabel) map.removeLayer(a.ann.layer._totalLabel);
        S.annotations = S.annotations.filter(x => x.id !== a.ann.id);
    } else if (a.type === 'clear') {
        a.anns.forEach(x => {
            map.removeLayer(x.layer);
            removeArrowHead(x);
            if (x.layer._totalLabel) map.removeLayer(x.layer._totalLabel);
        });
        S.annotations = [];
    }
    if (S.tool === 'eraser') { disableEraser(); enableEraser(); }
    S.undoStack.push(a);
    updateCount(); updateUndoRedoUI();
}

function updateUndoRedoUI() {
    $('#btn-undo').disabled = S.undoStack.length === 0;
    $('#btn-redo').disabled = S.redoStack.length === 0;
}

/* =====================================================
   Annotation Management
   ===================================================== */
function storeAnnotation(layer, type, coords, extra, options) {
    const ann = {
        id: S.nextId++,
        layer, type, coords,
        color: S.color,
        weight: S.weight,
        dashStyle: S.dashStyle,
        dashArray: DASH[S.dashStyle],
        extra: extra || null,
        locked: (options && options.locked) || false
    };
    layer._annId = ann.id;
    S.annotations.push(ann);
    pushUndo({ type: 'add', ann });
    updateCount();
}

function removeAnnotation(id) {
    const i = S.annotations.findIndex(a => a.id === id);
    if (i === -1) return;
    const ann = S.annotations[i];
    removeEraserHandlersFor(ann);
    map.removeLayer(ann.layer);
    removeArrowHead(ann);
    /* Also remove the total label tooltip for measurement annotations */
    if (ann.layer._totalLabel) {
        map.removeLayer(ann.layer._totalLabel);
    }
    S.annotations.splice(i, 1);
    pushUndo({ type: 'remove', ann });
    updateCount();
}

function clearAll() {
    if (S.annotations.length === 0) return;
    if (!confirm('Clear all annotations? You can undo this.')) return;
    disableEraser();
    const snapshot = S.annotations.slice();
    S.annotations.forEach(a => {
        map.removeLayer(a.layer);
        removeArrowHead(a);
        if (a.layer._totalLabel) map.removeLayer(a.layer._totalLabel);
    });
    S.annotations = [];
    pushUndo({ type: 'clear', anns: snapshot });
    updateCount();
}

function updateLockButton() {
    const allLocked = S.annotations.length > 0 && S.annotations.every(a => a.locked);
    const btn = $('#btn-lock');
    if (btn) {
        btn.textContent = allLocked ? '🔓 Unlock' : '🔒 Lock';
        btn.title = allLocked ? 'Unlock all annotations (erasable)' : 'Lock all annotations (eraser-proof)';
    }
}

function toggleLockAll() {
    if (S.annotations.length === 0) return;
    const allLocked = S.annotations.every(a => a.locked);
    S.annotations.forEach(a => { a.locked = !allLocked; });
    updateLockButton();
    if (S.tool === 'eraser') { disableEraser(); enableEraser(); }
    $('#status-text').textContent = allLocked ? 'All annotations unlocked' : 'All annotations locked';
}

function updateCount() {
    $('#ann-count').textContent = S.annotations.length + ' annotation' + (S.annotations.length !== 1 ? 's' : '');
    updateLockButton();
}

/* =====================================================
   Region Highlight — double-click toggle
   ===================================================== */
function toggleHighlight(layer) {
    /* If clicking the already-highlighted polygon, un-highlight it */
    if (S.highlighted === layer) {
        layer.setStyle(S.highlightedOrigStyle);
        layer.bringToBack();
        S.highlighted = null;
        S.highlightedOrigStyle = null;
        return;
    }
    /* Un-highlight previous if any */
    if (S.highlighted) {
        S.highlighted.setStyle(S.highlightedOrigStyle);
        S.highlighted.bringToBack();
    }
    /* Store original style and apply highlight */
    S.highlightedOrigStyle = Object.assign({}, layer.options);
    S.highlighted = layer;
    layer.setStyle({
        color: '#ffdd00',
        weight: 7,
        opacity: 1,
        fillOpacity: 0.35,
        dashArray: ''
    });
    layer.bringToFront();
}

/* Attach double-click highlight to a polygon layer */
function attachHighlightHandler(layer) {
    layer.on('dblclick', function (e) {
        if (e && e.originalEvent) L.DomEvent.stop(e.originalEvent);
        toggleHighlight(this);
    });
}

/* =====================================================
   Smoothing — Ramer-Douglas-Peucker + Catmull-Rom
   ===================================================== */
function rdpSimplify(pts, tol) {
    if (pts.length <= 2) return pts.slice();
    let maxD = 0, maxI = 0;
    const a = pts[0], b = pts[pts.length - 1];
    for (let i = 1; i < pts.length - 1; i++) {
        const d = ptSegDist(pts[i], a, b);
        if (d > maxD) { maxD = d; maxI = i; }
    }
    if (maxD > tol) {
        const l = rdpSimplify(pts.slice(0, maxI + 1), tol);
        const r = rdpSimplify(pts.slice(maxI), tol);
        return l.slice(0, -1).concat(r);
    }
    return [a, b];
}

function ptSegDist(p, a, b) {
    const dy = b[0] - a[0], dx = b[1] - a[1];
    const lenSq = dy * dy + dx * dx;
    if (lenSq === 0) return Math.hypot(p[0] - a[0], p[1] - a[1]);
    let t = ((p[0] - a[0]) * dy + (p[1] - a[1]) * dx) / lenSq;
    t = Math.max(0, Math.min(1, t));
    return Math.hypot(p[0] - (a[0] + t * dy), p[1] - (a[1] + t * dx));
}

function catmullRom(pts, seg) {
    if (pts.length < 3) return pts.slice();
    const out = [];
    for (let i = 0; i < pts.length - 1; i++) {
        const p0 = pts[Math.max(0, i - 1)];
        const p1 = pts[i];
        const p2 = pts[Math.min(pts.length - 1, i + 1)];
        const p3 = pts[Math.min(pts.length - 1, i + 2)];
        for (let j = 0; j < seg; j++) {
            const t = j / seg, t2 = t * t, t3 = t2 * t;
            out.push([
                0.5 * (2*p1[0] + (-p0[0]+p2[0])*t + (2*p0[0]-5*p1[0]+4*p2[0]-p3[0])*t2 + (-p0[0]+3*p1[0]-3*p2[0]+p3[0])*t3),
                0.5 * (2*p1[1] + (-p0[1]+p2[1])*t + (2*p0[1]-5*p1[1]+4*p2[1]-p3[1])*t2 + (-p0[1]+3*p1[1]-3*p2[1]+p3[1])*t3)
            ]);
        }
    }
    out.push(pts[pts.length - 1]);
    return out;
}

/* =====================================================
   Export — PNG (via html2canvas)
   ===================================================== */
function exportPNG() {
    const btn = $('#btn-png');
    btn.disabled = true;
    btn.textContent = '⏳ …';
    /* temporarily show finish btn hidden */
    const finishWasHidden = $('#btn-finish').classList.contains('hidden');
    $('#btn-finish').classList.add('hidden');

    /* Hide Leaflet controls so they don't appear in the screenshot */
    const controls = document.querySelectorAll('#map .leaflet-control');
    controls.forEach(c => { c.style.visibility = 'hidden'; });

    html2canvas(document.getElementById('map'), {
        useCORS: true, allowTaint: true, scale: 1
    }).then(canvas => {
        const a = document.createElement('a');
        a.download = 'map-' + Date.now() + '.png';
        a.href = canvas.toDataURL('image/png');
        a.click();
    }).catch(err => {
        console.error('PNG export failed:', err);
        alert('PNG export failed. Try using your browser\'s screenshot feature instead.');
    }).finally(() => {
        /* Restore Leaflet controls */
        controls.forEach(c => { c.style.visibility = ''; });
        btn.disabled = false;
        btn.textContent = '\uD83D\uDCF7 PNG';
        if (false) {
            $('#btn-finish').classList.remove('hidden');
        }
    });
}

/* =====================================================
   Export — GeoJSON
   ===================================================== */
function exportGeoJSON() {
    if (S.annotations.length === 0) {
        alert('No annotations to export.');
        return;
    }
    const features = S.annotations.map(a => {
        const isPoint = a.type === 'marker' || a.type === 'label';
        return {
            type: 'Feature',
            properties: {
                id: a.id, type: a.type, color: a.color,
                weight: a.weight, dashStyle: a.dashStyle,
                text: (a.extra && a.extra.text) || undefined
            },
            geometry: isPoint
                ? { type: 'Point', coordinates: [a.coords[1], a.coords[0]] }
                : { type: 'LineString', coordinates: a.coords.map(c => [c[1], c[0]]) }
        };
    });
    const geojson = {
        type: 'FeatureCollection',
        crs: { type: 'name', properties: { name: 'urn:ogc:def:crs:OGC:1.3:CRS84' } },
        features
    };
    const blob = new Blob([JSON.stringify(geojson, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.download = 'annotations-' + Date.now() + '.geojson';
    a.href = url;
    a.click();
    URL.revokeObjectURL(url);
}

/* =====================================================
   Import Modal — State & Helpers
   ===================================================== */
let importPendingFeatures = [];
window._importedMaps = [];       /* Array of { name, layerGroup, features, visible } */
window._pendingImportName = null; /* Pre-fill name for next renderPreview() call */

/* ── Built-in Presets ────────────────────────── */
const BUILT_IN_PRESETS = [
    /* ── 1. WWI Western Front ──────────────────── */
    {
        name: 'WWI Western Front',
        desc: 'Allied & German front lines, Hindenburg Line, key battles 1914-1918',
        geojson:{type:'FeatureCollection',features:[
            /* Entente (Allied) front line — Nieuport to Swiss border (approx 1917-18) */
            {type:'Feature',properties:{type:'polyline',color:'#ff4444',weight:3,dashStyle:'dashed',text:'Entente Front Line (1917-18)'},geometry:{type:'LineString',coordinates:[
                [2.92,51.13],[2.86,51.03],[2.89,50.85],[2.89,50.77],
                [2.85,50.61],[2.77,50.43],[2.77,50.35],[2.85,50.20],
                [2.93,50.09],[3.07,50.01],[3.18,49.93],[2.95,49.80],
                [3.10,49.65],[3.55,49.44],[3.82,49.25],[4.50,49.20],
                [5.38,49.16],[5.80,49.13],[6.18,49.12],[6.50,48.95],
                [6.90,48.78],[7.30,48.58],[7.75,48.58],[7.50,48.20],
                [7.34,47.75],[6.86,47.64],[7.58,47.56]
            ]}},
            /* Central Powers front line — offset east of Allied line */
            {type:'Feature',properties:{type:'polyline',color:'#4488ff',weight:3,dashStyle:'dashed',text:'Central Powers Front (1917-18)'},geometry:{type:'LineString',coordinates:[
                [3.12,51.13],[3.06,51.03],[3.09,50.85],[3.09,50.77],
                [3.05,50.61],[2.97,50.43],[2.97,50.35],[3.05,50.20],
                [3.13,50.09],[3.27,50.01],[3.38,49.93],[3.15,49.80],
                [3.30,49.65],[3.75,49.44],[4.02,49.25],[4.70,49.20],
                [5.58,49.16],[6.00,49.13],[6.38,49.12],[6.70,48.95],
                [7.10,48.78],[7.50,48.58],[7.95,48.58],[7.70,48.20],
                [7.54,47.75],[7.06,47.64],[7.78,47.56]
            ]}},
            /* Hindenburg Line (Siegfriedstellung) — German defensive position */
            {type:'Feature',properties:{type:'polyline',color:'#ffaa00',weight:2,dashStyle:'dotted',text:'Hindenburg Line (Siegfriedstellung)'},geometry:{type:'LineString',coordinates:[
                [3.20,51.00],[3.25,50.90],[3.15,50.70],[3.10,50.55],
                [3.10,50.40],[3.15,50.25],[3.35,50.05],[3.50,49.95],
                [3.40,49.85],[3.55,49.70],[3.85,49.50],[4.10,49.35],
                [4.40,49.28],[5.10,49.22],[5.70,49.18]
            ]}},
            /* Battle markers */
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Nieuport (1914, 1918)'},geometry:{type:'Point',coordinates:[2.92,51.13]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Ypres (1914-18, 3 battles)'},geometry:{type:'Point',coordinates:[2.87,50.85]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Passchendaele (1917)'},geometry:{type:'Point',coordinates:[2.95,50.90]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Messines Ridge (1917)'},geometry:{type:'Point',coordinates:[2.89,50.77]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Loos (1915)'},geometry:{type:'Point',coordinates:[2.77,50.43]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Arras (1917)'},geometry:{type:'Point',coordinates:[2.78,50.29]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Vimy Ridge (1917)'},geometry:{type:'Point',coordinates:[2.77,50.35]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Somme (1916)'},geometry:{type:'Point',coordinates:[2.70,50.01]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Cambrai (1917, first tanks)'},geometry:{type:'Point',coordinates:[3.24,50.18]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Chemin des Dames (1917)'},geometry:{type:'Point',coordinates:[3.55,49.44]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'2nd Battle of the Marne (1918)'},geometry:{type:'Point',coordinates:[3.60,49.08]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Verdun (1916, 300 days)'},geometry:{type:'Point',coordinates:[5.38,49.16]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Metz'},geometry:{type:'Point',coordinates:[6.18,49.12]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Strasbourg'},geometry:{type:'Point',coordinates:[7.75,48.58]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Belfort'},geometry:{type:'Point',coordinates:[6.86,47.64]}},
            /* Area labels */
            {type:'Feature',properties:{type:'label',color:'#ff6644',text:'Allied-held France'},geometry:{type:'Point',coordinates:[2.5,49.5]}},
            {type:'Feature',properties:{type:'label',color:'#4488ff',text:'German-occupied Belgium & France'},geometry:{type:'Point',coordinates:[4.5,50.0]}}
        ]}
    },
    /* ── 2. WWII Eastern Front ──────────────────── */
    {
        name: 'WWII Eastern Front',
        desc: 'Barbarossa, max German advance (1942), Soviet counter-offensive to Berlin',
        geojson:{type:'FeatureCollection',features:[
            /* Barbarossa start line — Baltic to Black Sea (Jun 22, 1941) */
            {type:'Feature',properties:{type:'polyline',color:'#ff2222',weight:3,dashStyle:'dashed',text:'Barbarossa Line (Jun 1941)'},geometry:{type:'LineString',coordinates:[
                [21.1,55.7],[22.8,54.1],[23.2,53.2],[23.7,52.1],
                [24.0,51.0],[24.0,50.0],[24.5,49.2],[25.0,48.5],
                [25.9,48.3],[27.6,47.1],[28.3,46.0]
            ]}},
            /* Max German advance — Leningrad to Caucasus (autumn 1942) */
            {type:'Feature',properties:{type:'polyline',color:'#ff8800',weight:3,dashStyle:'solid',text:'Max German Advance (autumn 1942)'},geometry:{type:'LineString',coordinates:[
                [30.0,59.9],[33.0,57.5],[34.5,56.2],[37.0,55.8],
                [36.5,54.0],[37.5,52.5],[39.2,51.7],[41.0,49.5],
                [43.5,48.7],[42.0,46.5],[44.0,44.0]
            ]}},
            /* Soviet counter-offensive path to Berlin (1943-45) */
            {type:'Feature',properties:{type:'polyline',color:'#44aaff',weight:3,dashStyle:'dashed',text:'Soviet Advance to Berlin (1943-45)'},geometry:{type:'LineString',coordinates:[
                [43.5,48.7],[41.0,47.5],[38.5,47.0],[36.0,46.5],
                [33.5,46.5],[31.5,48.5],[30.5,50.5],[28.0,51.5],
                [24.0,53.0],[21.0,52.2],[18.5,52.0],[15.0,52.5],
                [13.4,52.5]
            ]}},
            /* City & battle markers */
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Leningrad (sieged 872 days)'},geometry:{type:'Point',coordinates:[30.3,59.93]}},
            {type:'Feature',properties:{type:'marker',color:'#ff8800',text:'Moscow (1941-42)'},geometry:{type:'Point',coordinates:[37.6,55.75]}},
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Stalingrad (1942-43)'},geometry:{type:'Point',coordinates:[43.5,48.7]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Kursk (1943, largest tank battle)'},geometry:{type:'Point',coordinates:[36.2,51.7]}},
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Minsk (1941, liberated 1944)'},geometry:{type:'Point',coordinates:[27.6,53.9]}},
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Smolensk (1941)'},geometry:{type:'Point',coordinates:[32.0,54.8]}},
            {type:'Feature',properties:{type:'marker',color:'#ff8800',text:'Kiev (1941, liberated 1943)'},geometry:{type:'Point',coordinates:[30.5,50.45]}},
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Sevastopol (1941-42)'},geometry:{type:'Point',coordinates:[33.5,44.6]}},
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Rostov-on-Don'},geometry:{type:'Point',coordinates:[39.7,47.2]}},
            {type:'Feature',properties:{type:'marker',color:'#ff8800',text:'Brest-Litovsk'},geometry:{type:'Point',coordinates:[23.7,52.1]}},
            {type:'Feature',properties:{type:'marker',color:'#ff8800',text:'Warsaw (1944 uprising)'},geometry:{type:'Point',coordinates:[21.0,52.2]}},
            {type:'Feature',properties:{type:'marker',color:'#ff8800',text:'Vienna (1945)'},geometry:{type:'Point',coordinates:[16.4,48.2]}},
            {type:'Feature',properties:{type:'marker',color:'#ff8800',text:'Budapest (1944-45 siege)'},geometry:{type:'Point',coordinates:[19.0,47.5]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Berlin (May 1945)'},geometry:{type:'Point',coordinates:[13.4,52.5]}},
            /* Labels */
            {type:'Feature',properties:{type:'label',color:'#ff6644',text:'Nazi-occupied Europe (1942)'},geometry:{type:'Point',coordinates:[28,50]}},
            {type:'Feature',properties:{type:'label',color:'#44aaff',text:'Soviet Union'},geometry:{type:'Point',coordinates:[50,53]}}
        ]}
    },
    /* ── 3. Napoleonic Campaigns ──────────────────── */
    {
        name: 'Napoleonic Campaigns',
        desc: 'Grande Armee routes & key battles, 1805-1815',
        geojson:{type:'FeatureCollection',features:[
            /* March to Moscow (Jun-Sep 1812) */
            {type:'Feature',properties:{type:'polyline',color:'#ffaa00',weight:3,dashStyle:'dotted',text:'March to Moscow (Jun-Sep 1812)'},geometry:{type:'LineString',coordinates:[
                [20.5,54.7],[21.0,54.7],[22.8,54.1],[23.7,52.1],
                [24.0,53.7],[26.0,54.5],[27.6,53.9],[28.5,53.7],
                [30.0,54.5],[32.0,54.8],[34.0,55.0],[36.0,55.5],
                [37.6,55.75]
            ]}},
            /* Retreat from Moscow (Oct-Dec 1812) */
            {type:'Feature',properties:{type:'polyline',color:'#ff4444',weight:3,dashStyle:'solid',text:'Retreat from Moscow (Oct-Dec 1812)'},geometry:{type:'LineString',coordinates:[
                [37.6,55.75],[36.0,55.3],[34.5,54.5],[33.0,54.0],
                [31.0,53.5],[29.0,53.0],[27.0,52.5],[25.0,52.0],
                [24.0,53.7],[23.0,54.0],[21.5,54.7],[20.5,54.7]
            ]}},
            /* Earlier campaign routes */
            {type:'Feature',properties:{type:'polyline',color:'#ff8800',weight:2,dashStyle:'dashed',text:'Austerlitz Campaign (1805)'},geometry:{type:'LineString',coordinates:[
                [2.35,48.86],[5.0,48.5],[7.0,48.0],[8.5,48.5],
                [10.0,48.4],[13.0,48.8],[15.0,49.0],[16.76,49.13]
            ]}},
            {type:'Feature',properties:{type:'polyline',color:'#ff8800',weight:2,dashStyle:'dashed',text:'Jena-Auerstedt Campaign (1806)'},geometry:{type:'LineString',coordinates:[
                [8.0,49.0],[9.0,49.5],[10.0,50.0],[11.0,50.5],[11.59,50.93]
            ]}},
            /* Battle markers */
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Austerlitz (Dec 1805)'},geometry:{type:'Point',coordinates:[16.76,49.13]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Jena-Auerstedt (Oct 1806)'},geometry:{type:'Point',coordinates:[11.59,50.93]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Friedland (Jun 1807)'},geometry:{type:'Point',coordinates:[20.89,54.40]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Borodino (Sep 1812)'},geometry:{type:'Point',coordinates:[35.82,55.53]}},
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Moscow (burned Sep 1812)'},geometry:{type:'Point',coordinates:[37.62,55.75]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Dresden (Aug 1813)'},geometry:{type:'Point',coordinates:[13.74,51.05]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Leipzig (Oct 1813, Battle of Nations)'},geometry:{type:'Point',coordinates:[12.37,51.34]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Lutzen (May 1813)'},geometry:{type:'Point',coordinates:[12.15,51.25]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Bautzen (May 1813)'},geometry:{type:'Point',coordinates:[14.42,51.18]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Waterloo (Jun 1815)'},geometry:{type:'Point',coordinates:[4.40,50.71]}},
            /* City markers */
            {type:'Feature',properties:{type:'marker',color:'#00bbff',text:'Paris (capital)'},geometry:{type:'Point',coordinates:[2.35,48.86]}},
            {type:'Feature',properties:{type:'marker',color:'#00bbff',text:'Bologne-sur-Mer (camp 1805)'},geometry:{type:'Point',coordinates:[1.61,50.73]}},
            {type:'Feature',properties:{type:'marker',color:'#00bbff',text:'Ulm (surrendered Oct 1805)'},geometry:{type:'Point',coordinates:[9.99,48.40]}},
            {type:'Feature',properties:{type:'marker',color:'#00bbff',text:'Tilsit (treaty Jul 1807)'},geometry:{type:'Point',coordinates:[21.88,55.08]}},
            /* Labels */
            {type:'Feature',properties:{type:'label',color:'#ffaa00',text:'Grande Armee'},geometry:{type:'Point',coordinates:[30,53]}},
            {type:'Feature',properties:{type:'label',color:'#4488ff',text:'Russian Empire'},geometry:{type:'Point',coordinates:[45,57]}}
        ]}
    },
    /* ── 4. Cold War Iron Curtain ──────────────────── */
    {
        name: 'Cold War Iron Curtain',
        desc: 'Division of Europe — NATO vs Warsaw Pact, 1945-1991',
        geojson:{type:'FeatureCollection',features:[
            /* Inner German border (East-West Germany) */
            {type:'Feature',properties:{type:'polyline',color:'#ff3333',weight:4,dashStyle:'dotted',text:'Inner German Border (1945-90)'},geometry:{type:'LineString',coordinates:[
                [10.87,53.96],[10.60,53.70],[10.30,53.40],[10.10,53.10],
                [9.90,52.80],[9.80,52.50],[9.75,52.20],[9.70,51.90],
                [9.80,51.60],[10.00,51.30],[10.20,51.10],[10.50,50.90],
                [10.80,50.70],[11.00,50.50],[11.20,50.35],[11.50,50.20],
                [11.80,50.05]
            ]}},
            /* Full Iron Curtain — Baltic to Adriatic */
            {type:'Feature',properties:{type:'polyline',color:'#ff3333',weight:4,dashStyle:'dotted',text:'Iron Curtain (full line)'},geometry:{type:'LineString',coordinates:[
                [10.87,53.96],[14.00,54.20],[14.30,53.90],[14.80,53.40],
                [15.00,53.00],[14.60,52.50],[14.70,52.00],[15.00,51.10],
                [15.50,50.70],[16.00,50.20],[16.50,49.60],[17.00,49.20],
                [17.50,48.80],[18.00,48.50],[18.50,48.20],[19.00,48.00],
                [20.00,47.80],[21.00,47.50],[22.00,47.00],[23.00,46.50],
                [24.00,46.00],[25.00,45.50],[26.00,45.00],[27.00,44.50],
                [28.00,44.00],[29.00,43.50]
            ]}},
            /* Oder-Neisse line (Poland western border) */
            {type:'Feature',properties:{type:'polyline',color:'#ffaa00',weight:2,dashStyle:'dashed',text:'Oder-Neisse Line'},geometry:{type:'LineString',coordinates:[
                [14.30,53.90],[14.20,53.50],[14.10,53.10],[14.00,52.70],
                [14.50,52.00],[14.70,51.60],[15.00,51.10]
            ]}},
            /* Berlin Wall */
            {type:'Feature',properties:{type:'polyline',color:'#ff0000',weight:3,dashStyle:'solid',text:'Berlin Wall (1961-89)'},geometry:{type:'LineString',coordinates:[
                [13.30,52.55],[13.25,52.52],[13.30,52.48],[13.38,52.45],
                [13.42,52.47],[13.46,52.50],[13.43,52.53],[13.38,52.55],
                [13.30,52.55]
            ]}},
            /* City markers */
            {type:'Feature',properties:{type:'marker',color:'#ff0000',text:'Berlin (divided city)'},geometry:{type:'Point',coordinates:[13.40,52.52]}},
            {type:'Feature',properties:{type:'marker',color:'#4488ff',text:'Vienna (withdrawn 1955)'},geometry:{type:'Point',coordinates:[16.37,48.21]}},
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Prague (1968 invasion)'},geometry:{type:'Point',coordinates:[14.42,50.08]}},
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Budapest (1956 uprising)'},geometry:{type:'Point',coordinates:[19.04,47.50]}},
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Warsaw (Pact HQ)'},geometry:{type:'Point',coordinates:[21.01,52.23]}},
            {type:'Feature',properties:{type:'marker',color:'#ff4444',text:'Moscow (Kremlin)'},geometry:{type:'Point',coordinates:[37.62,55.75]}},
            {type:'Feature',properties:{type:'marker',color:'#4488ff',text:'Helsinki (Finland, neutral)'},geometry:{type:'Point',coordinates:[24.94,60.17]}},
            {type:'Feature',properties:{type:'marker',color:'#4488ff',text:'Belgrade (Non-Aligned)'},geometry:{type:'Point',coordinates:[20.45,44.82]}},
            /* Labels */
            {type:'Feature',properties:{type:'label',color:'#4488ff',text:'NATO'},geometry:{type:'Point',coordinates:[8,50]}},
            {type:'Feature',properties:{type:'label',color:'#ff4444',text:'Warsaw Pact'},geometry:{type:'Point',coordinates:[25,50]}},
            {type:'Feature',properties:{type:'label',color:'#44aa44',text:'Non-Aligned / Neutral'},geometry:{type:'Point',coordinates:[18,46]}}
        ]}
    },
    /* ── 5. Modern Ukraine Conflict ──────────────────── */
    {
        name: 'Modern Ukraine Conflict',
        desc: 'Front lines & key cities, 2022-present (approx late 2024)',
        geojson:{type:'FeatureCollection',features:[
            /* Front line (approx late 2024) */
            {type:'Feature',properties:{type:'polyline',color:'#ff4444',weight:3,dashStyle:'dashed',text:'Front Line (approx late 2024)'},geometry:{type:'LineString',coordinates:[
                [37.3,49.9],[37.2,49.5],[37.0,49.0],[37.3,48.7],
                [37.8,48.4],[38.0,48.1],[37.8,47.8],[37.5,47.5],
                [37.0,47.2],[36.5,46.9],[36.0,46.5],[35.5,46.2],
                [35.0,46.0],[34.5,46.3],[34.0,46.6],[33.7,46.8]
            ]}},
            /* Crimea annexation outline */
            {type:'Feature',properties:{type:'polyline',color:'#ff8800',weight:2,dashStyle:'dotted',text:'Crimea (annexed 2014)'},geometry:{type:'LineString',coordinates:[
                [33.5,46.0],[33.8,45.5],[34.0,45.0],[34.5,44.5],
                [35.0,44.2],[35.5,44.0],[36.0,44.2],[36.5,44.5],
                [36.6,45.0],[36.5,45.5],[36.0,45.8],[35.5,46.0],
                [35.0,46.1],[34.5,46.2],[34.0,46.1],[33.5,46.0]
            ]}},
            /* Russian border */
            {type:'Feature',properties:{type:'polyline',color:'#888888',weight:2,dashStyle:'solid',text:'International border'},geometry:{type:'LineString',coordinates:[
                [38.0,52.1],[37.5,51.5],[37.0,51.0],[36.5,50.5],
                [36.0,50.0],[35.5,49.5],[35.0,49.0],[36.5,48.5],
                [37.0,48.0],[36.5,47.5],[35.5,47.0],[35.0,46.5],[34.5,46.0]
            ]}},
            /* City markers */
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Kyiv (capital, defended)'},geometry:{type:'Point',coordinates:[30.52,50.45]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Kharkiv (2nd city, near front)'},geometry:{type:'Point',coordinates:[36.23,49.99]}},
            {type:'Feature',properties:{type:'marker',color:'#ff6644',text:'Mariupol (fell May 2022)'},geometry:{type:'Point',coordinates:[37.54,47.10]}},
            {type:'Feature',properties:{type:'marker',color:'#ff6644',text:'Bakhmut (fell May 2023)'},geometry:{type:'Point',coordinates:[38.00,48.60]}},
            {type:'Feature',properties:{type:'marker',color:'#ff6644',text:'Avdiivka (fell Feb 2024)'},geometry:{type:'Point',coordinates:[37.75,48.13]}},
            {type:'Feature',properties:{type:'marker',color:'#ff6644',text:'Donetsk (occupied since 2014)'},geometry:{type:'Point',coordinates:[37.80,48.00]}},
            {type:'Feature',properties:{type:'marker',color:'#ff6644',text:'Luhansk (occupied since 2014)'},geometry:{type:'Point',coordinates:[39.30,48.57]}},
            {type:'Feature',properties:{type:'marker',color:'#ff6644',text:'Zaporizhzhia (frontline city)'},geometry:{type:'Point',coordinates:[35.15,47.84]}},
            {type:'Feature',properties:{type:'marker',color:'#ff8800',text:'Kherson (liberated Nov 2022)'},geometry:{type:'Point',coordinates:[32.62,46.64]}},
            {type:'Feature',properties:{type:'marker',color:'#ff6644',text:'Sevastopol (naval base)'},geometry:{type:'Point',coordinates:[33.53,44.62]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Odesa (port city)'},geometry:{type:'Point',coordinates:[30.73,46.48]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Lviv (western hub)'},geometry:{type:'Point',coordinates:[24.03,49.84]}},
            {type:'Feature',properties:{type:'label',color:'#44aaff',text:'Ukrainian-controlled'},geometry:{type:'Point',coordinates:[32,49]}},
            {type:'Feature',properties:{type:'label',color:'#ff4444',text:'Russian-occupied'},geometry:{type:'Point',coordinates:[38,48.5]}}
        ]}
    },
    /* ── 6. WWII Western Front & D-Day ──────────────── */
    {
        name: 'WWII Western Front & D-Day',
        desc: 'Atlantic Wall, D-Day landings, Battle of the Bulge 1944-45',
        geojson:{type:'FeatureCollection',features:[
            /* Atlantic Wall — occupied European coastline */
            {type:'Feature',properties:{type:'polyline',color:'#666666',weight:2,dashStyle:'dashed',text:'Atlantic Wall (Fortifications)'},geometry:{type:'LineString',coordinates:[
                [-5.0,48.5],[-2.0,48.7],[0.0,49.3],[1.0,49.5],
                [1.6,50.0],[1.8,50.5],[2.9,51.1],[3.5,51.4],
                [4.0,51.9],[4.5,52.2],[5.0,52.7],[5.5,53.2],
                [6.0,53.5],[7.0,54.0],[8.0,54.5],[9.0,55.0],
                [10.0,55.5],[12.0,56.0],[12.5,56.5]
            ]}},
            /* D-Day front line — Normandy beaches */
            {type:'Feature',properties:{type:'polyline',color:'#44aaff',weight:3,dashStyle:'solid',text:'D-Day Front Line (Jun 6, 1944)'},geometry:{type:'LineString',coordinates:[
                [-1.2,49.7],[-0.8,49.6],[-0.5,49.4],[-0.3,49.3],
                [0.0,49.2],[0.3,49.15],[0.6,49.10]
            ]}},
            /* Breakout from Normandy */
            {type:'Feature',properties:{type:'polyline',color:'#44aaff',weight:2,dashStyle:'dashed',text:'Breakout from Normandy (Jul-Aug 1944)'},geometry:{type:'LineString',coordinates:[
                [-0.3,49.3],[0.5,49.0],[1.5,48.5],[2.0,48.2],
                [2.5,48.0],[3.0,48.5],[3.5,49.0],[4.0,49.5]
            ]}},
            /* Battle of the Bulge salient */
            {type:'Feature',properties:{type:'polyline',color:'#ff8800',weight:3,dashStyle:'dashed',text:'Battle of the Bulge (Dec 1944)'},geometry:{type:'LineString',coordinates:[
                [5.5,50.5],[5.8,50.3],[6.0,50.1],[5.8,49.9],
                [6.0,49.7],[6.3,49.8],[6.5,50.0],[6.3,50.2],
                [6.0,50.4],[5.5,50.5]
            ]}},
            /* D-Day landing beach markers */
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Utah Beach'},geometry:{type:'Point',coordinates:[-1.17,49.42]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Omaha Beach'},geometry:{type:'Point',coordinates:[-0.87,49.36]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Gold Beach'},geometry:{type:'Point',coordinates:[-0.25,49.36]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Juno Beach'},geometry:{type:'Point',coordinates:[-0.20,49.33]}},
            {type:'Feature',properties:{type:'marker',color:'#ffcc00',text:'Sword Beach'},geometry:{type:'Point',coordinates:[-0.10,49.31]}},
            /* Key city markers */
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Cherbourg (captured Jun 1944)'},geometry:{type:'Point',coordinates:[-1.62,49.64]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Caen (fierce fighting Jul 1944)'},geometry:{type:'Point',coordinates:[-0.37,49.18]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Paris (liberated Aug 25, 1944)'},geometry:{type:'Point',coordinates:[2.35,48.86]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Brussels (liberated Sep 1944)'},geometry:{type:'Point',coordinates:[4.35,50.85]}},
            {type:'Feature',properties:{type:'marker',color:'#ff8800',text:'Bastogne (Bulge siege)'},geometry:{type:'Point',coordinates:[5.72,50.00]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Remagen Bridge (Mar 1945)'},geometry:{type:'Point',coordinates:[7.77,50.58]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Berlin (fell May 2, 1945)'},geometry:{type:'Point',coordinates:[13.40,52.52]}},
            {type:'Feature',properties:{type:'marker',color:'#44aaff',text:'Rhineland crossing (Mar 1945)'},geometry:{type:'Point',coordinates:[6.80,51.00]}},
            /* Labels */
            {type:'Feature',properties:{type:'label',color:'#ff6644',text:'German-occupied France'},geometry:{type:'Point',coordinates:[2.0,50.0]}},
            {type:'Feature',properties:{type:'label',color:'#44aaff',text:'Allied advance'},geometry:{type:'Point',coordinates:[5.5,49.0]}}
        ]}
    }
];

/* ── localStorage helpers ──────────────────────── */
const LS_KEY = 'map_saved_maps';
function getSavedMaps() {
    try { return JSON.parse(localStorage.getItem(LS_KEY)) || []; } catch { return []; }
}
function saveMapToStorage(name, annotations) {
    const saved = getSavedMaps();
    const features = annotations.map(a => {
        const isPoint = a.type === 'marker' || a.type === 'label';
        return {
            type: 'Feature',
            properties: { id: a.id, type: a.type, color: a.color, weight: a.weight, dashStyle: a.dashStyle, text: (a.extra && a.extra.text) || undefined },
            geometry: isPoint
                ? { type: 'Point', coordinates: [a.coords[1], a.coords[0]] }
                : { type: 'LineString', coordinates: a.coords.map(c => [c[1], c[0]]) }
        };
    });
    const entry = { name, date: new Date().toISOString(), annotationCount: annotations.length, geojson: { type: 'FeatureCollection', features } };
    const idx = saved.findIndex(s => s.name === name);
    if (idx >= 0) saved[idx] = entry; else saved.push(entry);
    localStorage.setItem(LS_KEY, JSON.stringify(saved));
}
function deleteSavedMap(name) {
    const saved = getSavedMaps().filter(s => s.name !== name);
    localStorage.setItem(LS_KEY, JSON.stringify(saved));
}

/* ── Import Modal Open / Close ─────────────────── */
function openImportModal() {
    $('#import-modal').classList.remove('hidden');
    importPendingFeatures = [];
    $('#import-preview').classList.add('hidden');
    $('#import-actions').classList.add('hidden');
    $('#import-url-input').value = '';
    $('#import-name-input').value = '';
    refreshPresetsTab();
}
function closeImportModal() {
    $('#import-modal').classList.add('hidden');
    importPendingFeatures = [];
}

/* ── Expand Multi* geometries ──────────────────── */
function expandGeometry(geom) {
    if (geom.type === 'MultiLineString') return geom.coordinates.map(c => ({type:'LineString',coordinates:c}));
    if (geom.type === 'Polygon') return geom.coordinates.map(ring => ({type:'LineString',coordinates:ring}));
    if (geom.type === 'MultiPolygon') {
        const out = [];
        geom.coordinates.forEach(poly => poly.forEach(ring => out.push({type:'LineString',coordinates:ring})));
        return out;
    }
    if (geom.type === 'MultiPoint') return geom.coordinates.map(c => ({type:'Point',coordinates:c}));
    return [geom];
}

/* ── Parse GeoJSON into preview features ──────── */
function parseGeoJSONForPreview(data) {
    const features = data.type === 'FeatureCollection' ? data.features
        : data.type === 'Feature' ? [data] : [];
    const parsed = [];
    features.forEach((f, idx) => {
        if (!f.geometry) return;
        const p = f.properties || {};
        const geoms = expandGeometry(f.geometry);
        geoms.forEach(g => {
            parsed.push({
                id: idx + '_' + parsed.length,
                name: p.text || p.name || p.label || (g.type === 'LineString' ? 'Line #' + (parsed.length + 1) : 'Pin #' + (parsed.length + 1)),
                type: p.type || (g.type === 'Point' ? (p.text ? 'label' : 'marker') : 'polyline'),
                color: p.color || '#ff0000',
                weight: p.weight || 3,
                dashStyle: p.dashStyle || 'solid',
                geometryType: g.type,
                geometry: g,
                text: p.text || undefined,
                checked: true
            });
        });
    });
    return parsed;
}

/* ── Render Preview List ──────────────────────── */
function renderPreview(features) {
    const list = $('#import-preview-list');
    list.innerHTML = '';
    const hasFolders = features.some(f => f.folder);
    if (hasFolders) {
        /* Group by folder for KML data */
        const groups = {};
        features.forEach((f, i) => {
            const g = f.folder || 'Other';
            if (!groups[g]) groups[g] = [];
            groups[g].push({ feat: f, idx: i });
        });
        Object.keys(groups).forEach(folderName => {
            const grp = groups[folderName];
            const hdr = document.createElement('div');
            hdr.className = 'preview-folder';
            hdr.innerHTML = '<input type="checkbox" class="folder-toggle" data-folder="' + escapeHtml(folderName) + '" checked>'
                + '<span class="folder-name">' + escapeHtml(folderName) + '</span>'
                + '<span class="folder-count">' + grp.length + ' features</span>';
            hdr.querySelector('.folder-toggle').addEventListener('change', e => {
                const checked = e.target.checked;
                grp.forEach(g => { features[g.idx].checked = checked; });
                list.querySelectorAll('.preview-item[data-folder="' + CSS.escape(folderName) + '"] input[type="checkbox"]')
                    .forEach(cb => cb.checked = checked);
                updateSelectAllState();
            });
            list.appendChild(hdr);
            grp.forEach(g => {
                const div = document.createElement('div');
                div.className = 'preview-item';
                div.dataset.folder = folderName;
                div.innerHTML = '<input type="checkbox" data-idx="' + g.idx + '"' + (g.feat.checked ? ' checked' : '') + '>'
                    + '<span class="preview-item-color" style="background:' + g.feat.color + '"></span>'
                    + '<span class="preview-item-label">' + escapeHtml(g.feat.name) + '</span>'
                    + '<span class="preview-item-type">' + g.feat.geometryType + '</span>';
                div.querySelector('input').addEventListener('change', e => {
                    features[g.idx].checked = e.target.checked;
                    const allChecked = grp.every(x => features[x.idx].checked);
                    list.querySelector('.folder-toggle[data-folder="' + CSS.escape(folderName) + '"]').checked = allChecked;
                    updateSelectAllState();
                });
                list.appendChild(div);
            });
        });
    } else {
        /* Flat list for GeoJSON data */
        features.forEach((f, i) => {
            const div = document.createElement('div');
            div.className = 'preview-item';
            div.innerHTML = '<input type="checkbox" data-idx="' + i + '"' + (f.checked ? ' checked' : '') + '>'
                + '<span class="preview-item-color" style="background:' + f.color + '"></span>'
                + '<span class="preview-item-label">' + escapeHtml(f.name) + '</span>'
                + '<span class="preview-item-type">' + f.geometryType + '</span>';
            div.querySelector('input').addEventListener('change', e => {
                features[i].checked = e.target.checked;
                updateSelectAllState();
            });
            list.appendChild(div);
        });
    }
    $('#import-preview-count').textContent = features.length + ' feature' + (features.length !== 1 ? 's' : '') + ' found';
    $('#import-preview').classList.remove('hidden');
    $('#import-actions').classList.remove('hidden');
    $('#import-select-all').checked = features.every(f => f.checked);
    /* Pre-fill import name from source or pending override */
    const nameInput = $('#import-name-input');
    if (window._pendingImportName) {
        nameInput.value = window._pendingImportName;
        window._pendingImportName = null;
    } else if (features.some(f => f.mapName)) {
        const mapName = features.find(f => f.mapName).mapName;
        nameInput.value = (mapName === 'Google Maps') ? 'Google Maps KML' : mapName;
    } else {
        const folders = new Set(features.map(f => f.folder || '').filter(Boolean));
        if ([...folders].some(f => /yandex/i.test(f))) nameInput.value = 'Yandex Map';
        else if ([...folders].some(f => /waypoint|route|track/i.test(f))) nameInput.value = 'GPX Import';
        else nameInput.value = 'GeoJSON Import';
    }
}

/* ── Select All Checkbox Sync ──────────────────── */
function updateSelectAllState() {
    const all = importPendingFeatures;
    $('#import-select-all').checked = all.length > 0 && all.every(f => f.checked);
}

/* ── Confirm Import ────────────────────────────── */
function confirmImport() {
    const toImport = importPendingFeatures.filter(f => f.checked);
    if (toImport.length === 0) { alert('No features selected.'); return; }

    /* Group by folder for layer control */
    const folderGroups = {};
    let count = 0;
    toImport.forEach(f => {
        const folder = f.folder || 'Imported';
        if (!folderGroups[folder]) folderGroups[folder] = L.layerGroup();
        const grp = folderGroups[folder];

        if (f.geometryType === 'LineString') {
            const coords = f.geometry.coordinates.map(c => [c[1], c[0]]);
            const layer = L.polyline(coords, {
                color: f.color, weight: f.weight, dashArray: DASH[f.dashStyle], opacity: 1,
                lineCap: 'round', lineJoin: 'round', renderer: canvasRenderer
            });
            /* Hover tooltip with name */
            layer.bindTooltip(f.name || '', { sticky: true, className: 'import-tooltip' });
            /* Store annotation — imported maps are locked (cannot be erased) */
            const prevColor = S.color, prevW = S.weight, prevDS = S.dashStyle;
            S.color = f.color; S.weight = f.weight; S.dashStyle = f.dashStyle;
            storeAnnotation(layer, f.type, coords, null, { locked: true });
            S.color = prevColor; S.weight = prevW; S.dashStyle = prevDS;
            layer.addTo(grp);
            count++;
        } else if (f.geometryType === 'Polygon') {
            const coords = f.geometry.coordinates.map(c => [c[1], c[0]]);
            const layer = L.polygon(coords, {
                color: f.color, fillColor: f.fillColor || f.color,
                fillOpacity: f.fillOpacity || 0.3,
                weight: Math.max(1, f.weight || 2), renderer: canvasRenderer
            });
            layer.bindTooltip(f.name || '', { sticky: true, className: 'import-tooltip' });
            const prevColor = S.color;
            S.color = f.fillColor || f.color;
            storeAnnotation(layer, 'polygon', f.geometry.coordinates, { text: f.text || f.name }, { locked: true });
            S.color = prevColor;
            layer.addTo(grp);
            attachHighlightHandler(layer);
            count++;
        } else if (f.geometryType === 'Point') {
            const ll = [f.geometry.coordinates[1], f.geometry.coordinates[0]];
            const latlng = L.latLng(ll);
            const text = f.text || f.name || '';
            const marker = L.circleMarker(latlng, {
                radius: 5, fillColor: f.color, color: '#fff',
                weight: 1.5, fillOpacity: 0.9, renderer: canvasRenderer
            });
            if (text) marker.bindPopup('<b>' + escapeHtml(text) + '</b>', { maxWidth: 250 });
            const prevColor = S.color;
            S.color = f.color;
            storeAnnotation(marker, f.type || 'marker', ll, { text }, { locked: true });
            S.color = prevColor;
            marker.addTo(grp);
            count++;
        }
    });

    /* Add all folder groups to map */
    const importedFolders = {};
    Object.keys(folderGroups).forEach(name => {
        folderGroups[name].addTo(map);
        importedFolders[name] = folderGroups[name];
    });

    /* Store in global imported maps registry and build panel */
    const importName = ($('#import-name-input').value || '').trim() || 'Imported Map';
    Object.keys(folderGroups).forEach(folderName => {
        const displayName = Object.keys(folderGroups).length === 1 ? importName : importName + ' — ' + folderName;
        const featuresInFolder = toImport.filter(f => (f.folder || 'Imported') === folderName);
        window._importedMaps.push({
            name: displayName,
            layerGroup: folderGroups[folderName],
            features: featuresInFolder,
            visible: true
        });
    });
    updateImportedMapsPanel();

    closeImportModal();
    if (count > 0) {
        $('#status-text').textContent = 'Imported ' + count + ' annotation' + (count !== 1 ? 's' : '') + ' from map.';
    }
}

/* ── Imported Maps Panel ──────────────────────── */
function updateImportedMapsPanel() {
    let panel = $('#imported-maps-panel');
    if (!panel) {
        panel = document.createElement('div');
        panel.id = 'imported-maps-panel';
        panel.classList.add('hidden');
        document.body.appendChild(panel);
    }
    if (window._importedMaps.length === 0) {
        panel.classList.add('hidden');
        return;
    }
    panel.classList.remove('hidden');

    /* Track which groups are expanded (persist across rebuilds) */
    if (!window._importedMapsExpanded) window._importedMapsExpanded = {};
    const expanded = window._importedMapsExpanded;

    /* Header */
    let html = '<div class="panel-header">'
        + '<span class="panel-title">📂 Imported Maps</span>'
        + '<button class="panel-collapse-all" id="imported-maps-collapse-all">Collapse All</button>'
        + '</div><div class="panel-body">';

    window._importedMaps.forEach((entry, idx) => {
        const featureCount = entry.features ? entry.features.length : 0;
        const isOpen = !!expanded[idx];
        html += '<div class="imported-map-group">'
            + '<div class="imported-map-row" data-idx="' + idx + '">'
            + '<input type="checkbox" ' + (entry.visible ? 'checked' : '') + ' class="imported-map-toggle" data-idx="' + idx + '">'
            + '<span class="imported-map-name">' + escapeHtml(entry.name) + '</span>'
            + '<span class="imported-map-count">' + featureCount + '</span>'
            + '<span class="imported-map-chevron' + (isOpen ? ' expanded' : '') + '" data-idx="' + idx + '">▸</span>'
            + '</div>'
            + '<div class="imported-map-features' + (isOpen ? ' expanded' : '') + '" data-idx="' + idx + '">';

        if (entry.features && entry.features.length > 0) {
            entry.features.forEach(f => {
                html += '<div class="imported-map-feature">'
                    + '<span class="imported-map-feature-color" style="background:' + (f.color || '#888') + '"></span>'
                    + '<span class="imported-map-feature-name">' + escapeHtml(f.name || 'Unnamed') + '</span>'
                    + '<span class="imported-map-feature-type">' + (f.geometryType || '') + '</span>'
                    + '</div>';
            });
        }
        html += '</div></div>';
    });

    html += '</div>';
    panel.innerHTML = html;

    /* ── Event handlers ── */
    /* Toggle layer visibility */
    panel.querySelectorAll('.imported-map-toggle').forEach(cb => {
        cb.addEventListener('change', e => {
            const idx = parseInt(e.target.dataset.idx);
            const entry = window._importedMaps[idx];
            if (!entry) return;
            entry.visible = e.target.checked;
            if (entry.visible) {
                entry.layerGroup.addTo(map);
            } else {
                map.removeLayer(entry.layerGroup);
            }
        });
    });

    /* Chevron toggle — clicking the entire row toggles checkbox AND chevron */
    panel.querySelectorAll('.imported-map-row').forEach(row => {
        row.addEventListener('click', e => {
            /* Don't double-fire if the checkbox itself was clicked */
            if (e.target.classList.contains('imported-map-toggle')) return;
            const idx = parseInt(row.dataset.idx);
            const cb = row.querySelector('.imported-map-toggle');
            if (cb) { cb.checked = !cb.checked; cb.dispatchEvent(new Event('change')); }
        });
    });

    /* Chevron toggle for feature list */
    panel.querySelectorAll('.imported-map-chevron').forEach(chev => {
        chev.addEventListener('click', e => {
            e.stopPropagation();
            const idx = parseInt(chev.dataset.idx);
            const featuresEl = panel.querySelector('.imported-map-features[data-idx="' + idx + '"]');
            if (!featuresEl) return;
            const isOpen = featuresEl.classList.contains('expanded');
            if (isOpen) {
                featuresEl.classList.remove('expanded');
                chev.classList.remove('expanded');
                expanded[idx] = false;
            } else {
                featuresEl.classList.add('expanded');
                chev.classList.add('expanded');
                expanded[idx] = true;
            }
        });
    });

    /* Collapse/Expand all */
    const collapseAllBtn = panel.querySelector('#imported-maps-collapse-all');
    if (collapseAllBtn) {
        collapseAllBtn.addEventListener('click', () => {
            const anyOpen = Object.values(expanded).some(v => v);
            const featureEls = panel.querySelectorAll('.imported-map-features');
            const chevEls = panel.querySelectorAll('.imported-map-chevron');
            if (anyOpen) {
                /* Collapse all */
                featureEls.forEach(el => el.classList.remove('expanded'));
                chevEls.forEach(el => el.classList.remove('expanded'));
                Object.keys(expanded).forEach(k => expanded[k] = false);
                collapseAllBtn.textContent = 'Expand All';
            } else {
                /* Expand all */
                featureEls.forEach(el => el.classList.add('expanded'));
                chevEls.forEach(el => el.classList.add('expanded'));
                window._importedMaps.forEach((_, i) => expanded[i] = true);
                collapseAllBtn.textContent = 'Collapse All';
            }
        });
    }
}

/* ── Presets Tab Rendering ─────────────────────── */
function refreshPresetsTab() {
    const saved = getSavedMaps();
    const savedSection = $('#preset-saved-section');
    const savedList = $('#preset-saved-list');
    const builtInList = $('#preset-built-in-list');

    if (saved.length > 0) {
        savedSection.classList.remove('hidden');
        savedList.innerHTML = '';
        saved.forEach(s => {
            const div = document.createElement('div');
            div.className = 'preset-item';
            div.innerHTML = '<div class="preset-item-info"><div class="preset-item-name">' + escapeHtml(s.name) + '</div>'
                + '<div class="preset-item-desc">' + s.annotationCount + ' annotations</div></div>'
                + '<div class="preset-item-actions">'
                + '<button class="preset-item-btn load-preset" data-type="saved" data-name="' + escapeHtml(s.name) + '">Load</button>'
                + '<button class="preset-item-btn delete-btn delete-preset" data-name="' + escapeHtml(s.name) + '">✕</button>'
                + '</div>';
            savedList.appendChild(div);
        });
    } else {
        savedSection.classList.add('hidden');
    }

    builtInList.innerHTML = '';
    BUILT_IN_PRESETS.forEach((p, i) => {
        const div = document.createElement('div');
        div.className = 'preset-item';
        div.innerHTML = '<div class="preset-item-info"><div class="preset-item-name">' + escapeHtml(p.name) + '</div>'
            + '<div class="preset-item-desc">' + escapeHtml(p.desc) + '</div></div>'
            + '<div class="preset-item-actions">'
            + '<button class="preset-item-btn load-preset" data-type="builtin" data-idx="' + i + '">Load</button>'
            + '</div>';
        builtInList.appendChild(div);
    });

    builtInList.querySelectorAll('.load-preset').forEach(btn => btn.addEventListener('click', () => {
        const idx = parseInt(btn.dataset.idx);
        if (BUILT_IN_PRESETS[idx]) { window._pendingImportName = BUILT_IN_PRESETS[idx].name; loadPresetIntoPreview(BUILT_IN_PRESETS[idx].geojson); }
    }));
    savedList.querySelectorAll('.load-preset').forEach(btn => btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        const mapData = getSavedMaps().find(s => s.name === name);
        if (mapData && mapData.geojson) { window._pendingImportName = name; loadPresetIntoPreview(mapData.geojson); }
    }));
    savedList.querySelectorAll('.delete-preset').forEach(btn => btn.addEventListener('click', () => {
        const name = btn.dataset.name;
        if (confirm('Delete saved map "' + name + '"?')) { deleteSavedMap(name); refreshPresetsTab(); }
    }));
}

function loadPresetIntoPreview(geojson) {
    importPendingFeatures = parseGeoJSONForPreview(geojson);
    if (importPendingFeatures.length === 0) { alert('No compatible features found.'); return; }
    renderPreview(importPendingFeatures);
}

/* ── Import Modal Event Wiring ─────────────────── */
function wireImportModal() {
    $('#btn-import').addEventListener('click', openImportModal);
    $('#import-modal-close').addEventListener('click', closeImportModal);
    $('#import-modal').addEventListener('click', e => {
        if (e.target === $('#import-modal')) closeImportModal();
    });

    $$('.import-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            $$('.import-tab').forEach(t => t.classList.remove('active'));
            $$('.import-tab-content').forEach(c => c.classList.remove('active'));
            tab.classList.add('active');
            const target = $('#import-tab-' + tab.dataset.tab);
            if (target) target.classList.add('active');
            importPendingFeatures = [];
            $('#import-preview').classList.add('hidden');
            $('#import-actions').classList.add('hidden');
        });
    });

    $('#import-browse-btn').addEventListener('click', () => $('#file-input').click());
    $('#file-input').addEventListener('change', e => {
        if (e.target.files.length > 0) { handleFileImport(e.target.files[0]); e.target.value = ''; }
    });

    const dz = $('#import-dropzone');
    dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('drag-over'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
    dz.addEventListener('drop', e => {
        e.preventDefault(); dz.classList.remove('drag-over');
        if (e.dataTransfer.files.length > 0) handleFileImport(e.dataTransfer.files[0]);
    });

    $('#import-url-btn').addEventListener('click', handleUrlImport);
    $('#import-url-input').addEventListener('keydown', e => { if (e.key === 'Enter') handleUrlImport(); });

    $('#import-select-all').addEventListener('change', e => {
        const checked = e.target.checked;
        importPendingFeatures.forEach(f => f.checked = checked);
        $$('#import-preview-list input[type="checkbox"]').forEach(cb => cb.checked = checked);
    });

    $('#import-cancel-btn').addEventListener('click', closeImportModal);
    $('#import-confirm-btn').addEventListener('click', confirmImport);
}

function handleFileImport(file) {
    const nameLC = file.name.toLowerCase();
    const isKML = nameLC.endsWith('.kml');
    const isKMZ = nameLC.endsWith('.kmz');
    const isGPX = nameLC.endsWith('.gpx');

    /* ── KMZ (zipped KML) — read as binary ────── */
    if (isKMZ) {
        if (typeof JSZip === 'undefined') { alert('JSZip library not loaded. Please refresh the page and try again.'); return; }
        const reader = new FileReader();
        reader.onload = function (ev) {
            JSZip.loadAsync(ev.target.result).then(zip => {
                const kmlFile = Object.keys(zip.files).find(f => f.toLowerCase().endsWith('.kml'));
                if (!kmlFile) { alert('No KML file found inside the KMZ archive.'); return; }
                return zip.files[kmlFile].async('string');
            }).then(kmlText => {
                if (!kmlText) return;
                try {
                    importPendingFeatures = parseKML(kmlText);
                    if (importPendingFeatures.length === 0) { alert('No compatible features found in KMZ.'); return; }
                    renderPreview(importPendingFeatures);
                } catch (err) {
                    if (err && err.isNetworkLink) {
                        const netUrl = err.url;
                        alert('This KMZ contains a Google Maps NetworkLink.\nFetching the full map data…');
                        const proxies = [_p + '/kml?url=', _pAlt + '/kml?url=', '', 'https://corsproxy.io/?', 'https://api.allorigins.win/raw?url='];
                        let attempt = 0;
                        function tryFetch() {
                            const target = proxies[attempt] ? proxies[attempt] + encodeURIComponent(netUrl) : netUrl;
                            return fetch(target).then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
                                .then(t => { if (!t.includes('<Placemark') && !t.includes('<Document')) throw new Error('Not KML'); return t; })
                                .catch(e => { attempt++; if (attempt < proxies.length) return tryFetch(); throw e; });
                        }
                        tryFetch().then(fullKml => {
                            importPendingFeatures = parseKML(fullKml);
                            if (importPendingFeatures.length === 0) { alert('No features found after fetching full KML.'); return; }
                            renderPreview(importPendingFeatures);
                        }).catch(fetchErr => {
                            console.error('NetworkLink fetch failed:', fetchErr);
                            openProxyModal('https://www.google.com/maps/d/viewer?mid=' + encodeURIComponent(netUrl));
                            startProxyPolling();
                        });
                    } else { alert('Failed to parse KML inside KMZ.\n' + (err.message || err)); }
                }
            }).catch(err => { console.error('KMZ unzip failed:', err); alert('Failed to open KMZ file.\n' + err.message); });
        };
        reader.readAsArrayBuffer(file);
        return;
    }

    /* ── GPX — read as text ────────────────────── */
    if (isGPX) {
        const reader = new FileReader();
        reader.onload = function (ev) {
            try {
                importPendingFeatures = parseGPX(ev.target.result);
                if (importPendingFeatures.length === 0) { alert('No compatible features found in GPX file.'); return; }
                renderPreview(importPendingFeatures);
            } catch (err) { console.error('GPX import failed:', err); alert('Failed to parse GPX file.\n' + (err.message || err)); }
        };
        reader.readAsText(file);
        return;
    }

    /* ── KML / GeoJSON — read as text ─────────── */
    const reader = new FileReader();
    reader.onload = function (ev) {
        const text = ev.target.result;
        if (isKML) {
            try {
                importPendingFeatures = parseKML(text);
                if (importPendingFeatures.length === 0) { alert('No compatible features found.'); return; }
                renderPreview(importPendingFeatures);
            } catch (err) {
                if (err && err.isNetworkLink) {
                    /* Google My Maps stub — fetch the real KML from the NetworkLink URL */
                    const netUrl = err.url;
                    const mapName = err.mapName || 'Google Maps';
                    alert('This KML is a Google Maps shortcut file.\nFetching the full map data…');
                    const proxies = [
                        _p + '/kml?url=', _pAlt + '/kml?url=',
                        '',
                        'https://corsproxy.io/?',
                        'https://api.allorigins.win/raw?url='
                    ];
                    let attempt = 0;
                    function tryFetch() {
                        const target = proxies[attempt] ? proxies[attempt] + encodeURIComponent(netUrl) : netUrl;
                        return fetch(target).then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
                            .then(t => { if (!t.includes('<Placemark') && !t.includes('<Document')) throw new Error('Not KML data'); return t; })
                            .catch(err => { attempt++; if (attempt < proxies.length) return tryFetch(); throw err; });
                    }
                    tryFetch().then(fullKml => {
                        importPendingFeatures = parseKML(fullKml);
                        if (importPendingFeatures.length === 0) { alert('No features found after fetching full KML.'); return; }
                        renderPreview(importPendingFeatures);
                    }).catch(fetchErr => {
                        console.error('NetworkLink fetch failed:', fetchErr);
                        openProxyModal('https://www.google.com/maps/d/viewer?mid=' + encodeURIComponent(netUrl));
                        startProxyPolling();
                    });
                } else {
                    alert('Failed to parse file.\n' + (err.message || err));
                }
            }
            return;
        }
        /* GeoJSON */
        try {
            importPendingFeatures = parseGeoJSONForPreview(JSON.parse(text));
            if (importPendingFeatures.length === 0) { alert('No compatible features found.'); return; }
            renderPreview(importPendingFeatures);
        } catch (err) {
            console.error('Import failed:', err);
            alert('Failed to parse file.\n' + err.message);
        }
    };
    reader.readAsText(file);
}

/* =====================================================
   Yandex Maps URL Import
   ===================================================== */
function parseYandexMapsUrl(url) {
    const isYandex = /yandex\.(ru|com|uz|by|kz)\/maps/.test(url);
    if (!isYandex) return null;
    try {
        const parsed = new URL(url);
        const params = parsed.searchParams;
        const result = {
            lat: null, lng: null, zoom: 15,
            points: [], route: [], searchText: null, spn: null, constructorHash: null
        };

        // Extract center from ll=lng,lat
        const ll = params.get('ll');
        if (ll) {
            const parts = ll.split(',');
            if (parts.length === 2) {
                result.lng = parseFloat(parts[0]);
                result.lat = parseFloat(parts[1]);
            }
        }

        // Extract zoom
        const z = params.get('z');
        if (z) result.zoom = parseInt(z, 10) || 15;

        // Extract span
        const spn = params.get('spn');
        if (spn) {
            const spnParts = spn.split(',');
            if (spnParts.length === 2) {
                result.spn = { lng: parseFloat(spnParts[0]), lat: parseFloat(spnParts[1]) };
            }
        }

        // Extract text search query
        const text = params.get('text');
        if (text) result.searchText = text;

        // Parse ALL pt points: pt=lng,lat,scale,type,flags~lng,lat,scale,type,flags~...
        const pt = params.get('pt');
        if (pt) {
            const ptSegments = pt.split('~');
            ptSegments.forEach(function(seg) {
                const p = seg.split(',');
                if (p.length >= 2) {
                    const lng = parseFloat(p[0]);
                    const lat = parseFloat(p[1]);
                    const scale = p.length >= 3 ? parseFloat(p[2]) : 949;
                    const type = p.length >= 4 ? parseInt(p[3], 10) : 0;
                    const flags = p.length >= 5 ? p[4] : '';
                    if (!isNaN(lat) && !isNaN(lng)) {
                        result.points.push({ lat: lat, lng: lng, scale: scale, type: type, flags: flags });
                    }
                }
            });
        }

        // Extract route from rtext=lat1,lng1~lat2,lng2~...
        const rtext = params.get('rtext');
        if (rtext) {
            const waypoints = rtext.split('~').map(function(wp) {
                const wpParts = wp.split(',');
                return { lat: parseFloat(wpParts[0]), lng: parseFloat(wpParts[1]) };
            }).filter(function(wp) { return !isNaN(wp.lat) && !isNaN(wp.lng); });
            if (waypoints.length >= 2) result.route = waypoints;
        }

        // Extract user map constructor hash from um=constructor:HASH
        const um = params.get('um');
        if (um) {
            const umMatch = um.match(/constructor:([a-f0-9]+)/i);
            if (umMatch) result.constructorHash = umMatch[1];
        }

        // If no coordinates found and no constructor hash, return null
        if (result.lat === null && result.lng === null && result.points.length === 0 && result.route.length === 0 && !result.constructorHash) return null;
        return result;
    } catch (_) {
        return null;
    }
}

function fetchYandexMapData(yandexData) {
    const features = [];
    let i = 0;

    // Create marker features for EACH parsed point
    if (yandexData.points && yandexData.points.length > 0) {
        yandexData.points.forEach(function(pt, idx) {
            const isBusiness = pt.type === 1;
            features.push({
                id: 'yandex_pt_' + (i++),
                name: 'Yandex Point ' + (idx + 1),
                type: 'marker',
                color: isBusiness ? '#ffaa00' : '#ff0000',
                weight: 3,
                dashStyle: 'solid',
                geometryType: 'Point',
                geometry: { type: 'Point', coordinates: [pt.lng, pt.lat] },
                text: (isBusiness ? 'POI' : 'Point') + ' ' + (idx + 1),
                checked: true,
                folder: 'Yandex Points'
            });
        });
    }

    // Create route polyline and individual route point markers
    if (yandexData.route && yandexData.route.length >= 2) {
        // Route polyline (dashed)
        features.push({
            id: 'yandex_route_' + (i++),
            name: 'Yandex Route',
            type: 'polyline',
            color: '#ff4444',
            weight: 3,
            dashStyle: 'dashed',
            geometryType: 'LineString',
            geometry: {
                type: 'LineString',
                coordinates: yandexData.route.map(function(wp) { return [wp.lng, wp.lat]; })
            },
            text: 'Route',
            checked: true,
            folder: 'Yandex Routes'
        });

        // Individual route point markers
        yandexData.route.forEach(function(wp, idx) {
            features.push({
                id: 'yandex_rt_' + (i++),
                name: 'Route Waypoint ' + (idx + 1),
                type: 'marker',
                color: '#ff4444',
                weight: 3,
                dashStyle: 'solid',
                geometryType: 'Point',
                geometry: { type: 'Point', coordinates: [wp.lng, wp.lat] },
                text: 'Waypoint ' + (idx + 1),
                checked: true,
                folder: 'Yandex Routes'
            });
        });
    }

    // Only create a center pin if there are no points and no route
    if (yandexData.points.length === 0 && yandexData.route.length === 0 && yandexData.lat !== null && yandexData.lng !== null) {
        features.push({
            id: 'yandex_center_' + (i++),
            name: 'Yandex Center',
            type: 'marker',
            color: '#ff0000',
            weight: 3,
            dashStyle: 'solid',
            geometryType: 'Point',
            geometry: { type: 'Point', coordinates: [yandexData.lng, yandexData.lat] },
            text: 'Center',
            checked: true,
            folder: 'Yandex Points'
        });
    }

    return features;
}

function fetchYandexConstructorMap(hash, btn) {
    const proxyBase = _p + '/?url=';
    const pageUrl = 'https://yandex.com/maps/?um=constructor:' + hash;

    return fetch(proxyBase + encodeURIComponent(pageUrl))
        .then(function(r) {
            if (!r.ok) throw new Error('Failed to fetch Yandex map page: HTTP ' + r.status);
            return r.text();
        })
        .then(function(html) {
            // Extract userMap.features JSON from the page
            var marker = '"userMap":{"features":[';
            var idx = html.indexOf(marker);
            if (idx < 0) throw new Error('Could not find map features in Yandex page');
            var arrStart = html.indexOf('[', idx);
            // Find matching closing bracket
            var depth = 0, end = -1;
            for (var i = arrStart; i < Math.min(arrStart + 2000000, html.length); i++) {
                if (html[i] === '[') depth++;
                else if (html[i] === ']') {
                    depth--;
                    if (depth === 0) { end = i + 1; break; }
                }
            }
            if (end < 0) throw new Error('Could not parse map features array');
            var featuresJson = html.substring(arrStart, end);
            var features = JSON.parse(featuresJson);
            return parseYandexConstructorFeatures(features);
        });
}

function parseYandexConstructorFeatures(features) {
    var result = [];
    var i = 0;

    features.forEach(function(f) {
        try {
            var name = f.title || 'Feature ' + (i + 1);
            var geom = f.geometry;
            if (!geom || !geom.coordinates) return;

            if (f.type === 'line' || geom.type === 'LineString') {
                var coords = geom.coordinates;
                if (coords.length < 2) return;
                var strokeColor = (f.stroke && f.stroke.color) ? f.stroke.color : '#4488ff';
                var strokeWidth = (f.stroke && f.stroke.width) ? f.stroke.width : 2;
                result.push({
                    id: 'ym_' + (i++),
                    name: name,
                    type: 'polyline',
                    color: strokeColor,
                    weight: strokeWidth,
                    dashStyle: 'solid',
                    geometryType: 'LineString',
                    geometry: { type: 'LineString', coordinates: coords },
                    text: name,
                    checked: true,
                    folder: 'Yandex Map'
                });
            } else if (f.type === 'polygon' || geom.type === 'Polygon') {
                /* Yandex coords are GeoJSON Polygon: [[ring1],[hole1],...].
                   The import system expects flat coords: [ring1 only]. */
                var polyCoords = geom.coordinates;
                if (Array.isArray(polyCoords[0]) && !Array.isArray(polyCoords[0][0])) {
                    /* Already flat [[lng,lat],...] — unexpected but fine */
                } else if (Array.isArray(polyCoords[0]) && Array.isArray(polyCoords[0][0])) {
                    /* Nested [[[lng,lat],...]] — unwrap first ring */
                    polyCoords = polyCoords[0];
                }
                if (!polyCoords || polyCoords.length < 3) return;
                var strokeColor = (f.stroke && f.stroke.color) ? f.stroke.color : '#ff4444';
                var strokeWidth = (f.stroke && f.stroke.width) ? f.stroke.width : 2;
                var fillColor = (f.fill && f.fill.color) ? f.fill.color : strokeColor;
                var fillOpacity = (f.fill && f.fill.opacity !== undefined) ? Math.max(f.fill.opacity, 0.35) : 0.35;
                result.push({
                    id: 'ym_' + (i++),
                    name: name,
                    type: 'polygon',
                    color: strokeColor,
                    fillColor: fillColor,
                    fillOpacity: fillOpacity,
                    weight: strokeWidth,
                    dashStyle: 'solid',
                    geometryType: 'Polygon',
                    geometry: { type: 'Polygon', coordinates: polyCoords },
                    text: name,
                    checked: true,
                    folder: 'Yandex Map'
                });
            }
        } catch (e) {
            console.warn('Skipping Yandex feature:', e);
        }
    });

    return result;
}

/* =====================================================
   Google My Maps KML Import
   ===================================================== */
function parseGoogleMapsUrl(url) {
    const p = /google\.com\/maps\/d\/(?:u\/\d+\/)?(?:viewer|edit|kml|embed(?:ded)?)\?.*mid=([a-zA-Z0-9_-]+)/;
    const m = url.match(p);
    return m ? m[1] : null;
}
function kmlColorToHex(kmlColor) {
    if (!kmlColor || kmlColor.length < 6) return '#888888';
    return '#' + (kmlColor.slice(6, 8) || '88') + (kmlColor.slice(4, 6) || '88') + (kmlColor.slice(2, 4) || '88');
}
function kmlWidthToWeight(w) {
    const n = parseFloat(w);
    if (isNaN(n) || n <= 0) return 2;
    if (n < 0.1) return Math.max(2, Math.round(n * 1000));
    if (n < 1) return Math.max(2, Math.round(n * 20));
    return Math.min(10, Math.max(2, Math.round(n)));
}
function resolveKmlStyle(styleUrl, styleMap) {
    if (!styleUrl) return { color: '#888888', width: 2, type: 'unknown' };
    let id = styleUrl.replace(/^#/, '');
    if (styleMap[id] && styleMap[id].normal) id = styleMap[id].normal;
    return styleMap[id] || { color: '#888888', width: 2, type: 'unknown' };
}
function kmlAlphaToOpacity(kmlColor) {
    if (!kmlColor || kmlColor.length < 2) return 0.3;
    const alpha = parseInt(kmlColor.slice(0, 2), 16);
    return isNaN(alpha) ? 0.3 : alpha / 255;
}

function buildKmlStyleMap(doc) {
    const styles = {};
    const styleEls = doc.getElementsByTagName('Style');
    Array.from(styleEls).forEach(s => {
        const id = s.getAttribute('id'); if (!id) return;
        const entry = {};
        const lineEl = s.getElementsByTagName('LineStyle')[0];
        const iconEl = s.getElementsByTagName('IconStyle')[0];
        const polyEl = s.getElementsByTagName('PolyStyle')[0];
        if (lineEl) {
            const c = lineEl.getElementsByTagName('color')[0];
            const w = lineEl.getElementsByTagName('width')[0];
            entry.color = c ? kmlColorToHex(c.textContent.trim()) : '#888888';
            entry.width = w ? kmlWidthToWeight(w.textContent.trim()) : 2;
            entry.type = 'line';
        } else if (iconEl) {
            const c = iconEl.getElementsByTagName('color')[0];
            entry.color = c ? kmlColorToHex(c.textContent.trim()) : '#888888';
            entry.width = 3; entry.type = 'icon';
        }
        if (polyEl) {
            const pc = polyEl.getElementsByTagName('color')[0];
            if (pc) {
                const raw = pc.textContent.trim();
                entry.fillColor = kmlColorToHex(raw);
                entry.fillOpacity = kmlAlphaToOpacity(raw);
            }
            if (!entry.color) entry.color = entry.fillColor || '#888888';
            if (!entry.type) entry.type = 'poly';
        }
        styles[id] = entry;
    });
    const styleMaps = doc.getElementsByTagName('StyleMap');
    Array.from(styleMaps).forEach(sm => {
        const id = sm.getAttribute('id'); if (!id) return;
        const pairs = {};
        Array.from(sm.children).forEach(p => {
            if (p.localName !== 'Pair') return;
            const k = p.getElementsByTagName('key')[0];
            const ref = p.getElementsByTagName('styleUrl')[0];
            if (k && ref) pairs[k.textContent.trim()] = ref.textContent.trim().replace(/^#/, '');
        });
        styles[id] = pairs.normal ? (styles[pairs.normal] || { normal: pairs.normal }) : pairs;
    });
    return styles;
}
function parseKmlCoords(text) {
    if (!text) return [];
    return text.trim().split(/\s+/).map(pair => {
        const p = pair.split(',');
        return [parseFloat(p[0]), parseFloat(p[1])]; /* KML lon,lat → store as lon,lat (GeoJSON convention) */
    }).filter(c => !isNaN(c[0]) && !isNaN(c[1]));
}
function extractKmlFeatures(node, styleMap, folderName) {
    const features = [];
    const children = Array.from(node.children || []);
    children.forEach(el => {
        if (el.localName === 'Placemark') {
            const nameEl = el.querySelector('name');
            const styleEl = el.querySelector('styleUrl');
            const name = (nameEl ? nameEl.textContent.trim() : '') || folderName || 'Unnamed';
            const style = resolveKmlStyle(styleEl ? styleEl.textContent.trim() : '', styleMap);

            const multiGeo = el.querySelector('MultiGeometry');
            if (multiGeo) { features.push(...extractKmlFeatures(multiGeo, styleMap, name)); return; }

            const pt = el.querySelector('Point > coordinates');
            if (pt) {
                const coords = parseKmlCoords(pt.textContent);
                if (coords.length > 0) features.push({ id:'kml_'+features.length, name, type: style.type==='icon'?'marker':'label',
                    color: style.color, weight: 3, dashStyle:'solid', geometryType:'Point',
                    geometry:{type:'Point',coordinates:[coords[0][0],coords[0][1]]}, text:name, checked:true, folder:folderName||'Ungrouped' });
                return;
            }
            const ls = el.querySelector('LineString > coordinates');
            if (ls) {
                const coords = parseKmlCoords(ls.textContent);
                if (coords.length > 1) features.push({ id:'kml_'+features.length, name, type:'polyline',
                    color: style.color, weight: style.width||2, dashStyle:'solid', geometryType:'LineString',
                    geometry:{type:'LineString',coordinates:coords}, text:name, checked:true, folder:folderName||'Ungrouped' });
                return;
            }
            const poly = el.querySelector('Polygon');
            if (poly) {
                const outer = poly.querySelector('outerBoundaryIs > LinearRing > coordinates');
                if (outer) {
                    const coords = parseKmlCoords(outer.textContent);
                    if (coords.length > 1) features.push({ id:'kml_'+features.length, name, type:'polygon',
                        color: style.color, fillColor: style.fillColor || style.color,
                        fillOpacity: style.fillOpacity || 0.3,
                        weight: Math.max(1, style.width||2), dashStyle:'solid', geometryType:'Polygon',
                        geometry:{type:'Polygon',coordinates:coords}, text:name, checked:true, folder:folderName||'Ungrouped' });
                }
            }
        } else if (el.localName === 'Folder' || el.localName === 'Document') {
            const subName = (el.querySelector('name') || {}).textContent || folderName || '';
            features.push(...extractKmlFeatures(el, styleMap, subName || folderName));
        }
    });
    return features;
}

function parseKML(kmlText) {
    /* Strip default KML namespace so getElementsByTagName works in browsers */
    kmlText = kmlText.replace(/xmlns="http:\/\/www\.opengis\.net\/kml\/2\.2"/g, '');
    const doc = new DOMParser().parseFromString(kmlText, 'application/xml');
    const parseErr = doc.querySelector('parsererror');
    if (parseErr) { console.error('KML parse error:', parseErr.textContent.slice(0, 300)); throw new Error('Invalid KML/XML'); }
    const root = doc.getElementsByTagName('Document')[0] || doc.getElementsByTagName('Folder')[0] || doc.documentElement;
    const nameEl = root.getElementsByTagName('name')[0];
    const docName = nameEl ? nameEl.textContent.trim() : 'Google Maps';

    /* Check for NetworkLink stub (Google My Maps download quirk) */
    const netLink = root.getElementsByTagName('NetworkLink')[0];
    if (netLink) {
        const linkHref = (netLink.getElementsByTagName('href')[0] || {}).textContent
            || (netLink.getElementsByTagName('link')[0] && netLink.getElementsByTagName('link')[0].getElementsByTagName('href')[0] || {}).textContent
            || '';
        if (linkHref) {
            throw { isNetworkLink: true, url: linkHref.trim(), mapName: docName };
        }
    }

    const styleMap = buildKmlStyleMap(doc);
    const features = extractKmlFeatures(root, styleMap, docName);
    features.forEach(f => { f.mapName = docName; });
    return features;
}

/* =====================================================
   GPX Import (GPS Exchange Format)
   ===================================================== */
function parseGPX(gpxText) {
    gpxText = gpxText.replace(/xmlns="http:\/\/www\.topografix\.com\/GPX\/1\/[12]"/g, '');
    const doc = new DOMParser().parseFromString(gpxText, 'application/xml');
    const parseErr = doc.querySelector('parsererror');
    if (parseErr) { console.error('GPX parse error:', parseErr.textContent.slice(0, 300)); throw new Error('Invalid GPX/XML'); }
    const features = [];
    let idx = 0;

    function getTagText(parent, tag) {
        const el = parent.getElementsByTagName(tag)[0];
        return el ? el.textContent.trim() : '';
    }

    /* Waypoints → Markers */
    const wpts = doc.getElementsByTagName('wpt');
    for (let i = 0; i < wpts.length; i++) {
        const wpt = wpts[i];
        const lat = parseFloat(wpt.getAttribute('lat'));
        const lon = parseFloat(wpt.getAttribute('lon'));
        if (isNaN(lat) || isNaN(lon)) continue;
        const name = getTagText(wpt, 'name') || getTagText(wpt, 'desc') || 'Waypoint ' + (idx + 1);
        const desc = getTagText(wpt, 'desc');
        features.push({ id: 'gpx_' + idx, name, type: 'label', color: '#ffcc00', weight: 3, dashStyle: 'solid',
            geometryType: 'Point', geometry: { type: 'Point', coordinates: [lon, lat] },
            text: desc ? name + '\n' + desc : name, checked: true, folder: 'Waypoints' });
        idx++;
    }

    /* Routes → Polylines */
    const routes = doc.getElementsByTagName('rte');
    for (let i = 0; i < routes.length; i++) {
        const rte = routes[i];
        const rteName = getTagText(rte, 'name') || 'Route ' + (i + 1);
        const rtepts = rte.getElementsByTagName('rtept');
        const coords = [];
        for (let j = 0; j < rtepts.length; j++) {
            const lat = parseFloat(rtepts[j].getAttribute('lat'));
            const lon = parseFloat(rtepts[j].getAttribute('lon'));
            if (!isNaN(lat) && !isNaN(lon)) coords.push([lon, lat]);
        }
        if (coords.length >= 2) {
            features.push({ id: 'gpx_' + idx, name: rteName, type: 'polyline', color: '#ff8800', weight: 3, dashStyle: 'dashed',
                geometryType: 'LineString', geometry: { type: 'LineString', coordinates: coords },
                text: rteName, checked: true, folder: 'Routes' });
            idx++;
        }
    }

    /* Tracks → Polylines */
    const tracks = doc.getElementsByTagName('trk');
    for (let i = 0; i < tracks.length; i++) {
        const trk = tracks[i];
        const trkName = getTagText(trk, 'name') || 'Track ' + (i + 1);
        const trksegs = trk.getElementsByTagName('trkseg');
        for (let s = 0; s < trksegs.length; s++) {
            const trkpts = trksegs[s].getElementsByTagName('trkpt');
            const coords = [];
            for (let j = 0; j < trkpts.length; j++) {
                const lat = parseFloat(trkpts[j].getAttribute('lat'));
                const lon = parseFloat(trkpts[j].getAttribute('lon'));
                if (!isNaN(lat) && !isNaN(lon)) coords.push([lon, lat]);
            }
            if (coords.length >= 2) {
                const segName = trksegs.length > 1 ? trkName + ' (segment ' + (s + 1) + ')' : trkName;
                features.push({ id: 'gpx_' + idx, name: segName, type: 'polyline', color: '#44aaff', weight: 3, dashStyle: 'solid',
                    geometryType: 'LineString', geometry: { type: 'LineString', coordinates: coords },
                    text: segName, checked: true, folder: 'Tracks' });
                idx++;
            }
        }
    }

    return features;
}

function fetchGoogleKML(mid, btn) {
    const kmlUrl = 'https://www.google.com/maps/d/u/0/kml?mid=' + mid + '&forcekml=1';
    const proxies = [
        _p + '/kml?url=', _pAlt + '/kml?url=',
        '',
        'https://corsproxy.io/?',
        'https://api.allorigins.win/raw?url='
    ];
    let attempt = 0;
    function tryFetch() {
        const target = proxies[attempt] ? proxies[attempt] + encodeURIComponent(kmlUrl) : kmlUrl;
        btn.textContent = attempt === 0 ? 'Fetching KML…' : 'Trying proxy…';
        return fetch(target).then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
            .then(t => { if (!t.includes('<kml') && !t.includes('<Document')) throw new Error('Not KML'); return t; })
            .catch(err => { attempt++; if (attempt < proxies.length) return tryFetch(); throw err; });
    }
    return tryFetch();
}

function handleUrlImport() {
    const url = $('#import-url-input').value.trim();
    if (!url) { alert('Please enter a URL.'); return; }
    const btn = $('#import-url-btn');
    btn.disabled = true; btn.textContent = 'Fetching…';

    /* ── Yandex Maps URL → local parse ────── */
    const yandexData = parseYandexMapsUrl(url);
    if (yandexData) {
        // Constructor maps need to fetch data from Yandex servers
        if (yandexData.constructorHash) {
            fetchYandexConstructorMap(yandexData.constructorHash, btn)
                .then(features => {
                    if (features.length === 0) {
                        // Fall back to URL params
                        const fallback = fetchYandexMapData(yandexData);
                        if (fallback.length === 0) { alert('No features found in this Yandex map.'); return; }
                        importPendingFeatures = fallback;
                    } else {
                        importPendingFeatures = features;
                    }
                    renderPreview(importPendingFeatures);
                })
                .catch(err => {
                    console.error('Yandex constructor map import failed:', err);
                    // Fall back to URL params
                    const fallback = fetchYandexMapData(yandexData);
                    if (fallback.length > 0) {
                        importPendingFeatures = fallback;
                        renderPreview(importPendingFeatures);
                    } else {
                        alert('Failed to import Yandex map.\n' + err.message);
                    }
                })
                .finally(() => { btn.disabled = false; btn.textContent = 'Fetch & Import'; });
            return;
        }
        // Simple URL-based map
        const yandexFeatures = fetchYandexMapData(yandexData);
        if (yandexFeatures.length === 0) { alert('No coordinates found in this Yandex Maps URL.'); btn.disabled = false; btn.textContent = 'Fetch & Import'; return; }
        importPendingFeatures = yandexFeatures;
        renderPreview(importPendingFeatures);
        btn.disabled = false; btn.textContent = 'Fetch & Import';
        return;
    }

    /* ── Google Maps URL → KML proxy flow ────── */
    const mid = parseGoogleMapsUrl(url);
    if (mid) {
        fetchGoogleKML(mid, btn).then(kmlText => {
            importPendingFeatures = parseKML(kmlText);
            if (importPendingFeatures.length === 0) { alert('No features found in this Google Map.'); return; }
            renderPreview(importPendingFeatures);
        }).catch(err => {
            console.error('KML import failed:', err);
            openProxyModal(url);
            startProxyPolling();
        }).finally(() => { btn.disabled = false; btn.textContent = 'Fetch & Import'; });
        return;
    }

    /* ── Detect format from URL extension ────── */
    const urlLower = url.split('?')[0].toLowerCase();
    const isGPXUrl = urlLower.endsWith('.gpx');
    const isKmlUrl = urlLower.endsWith('.kml');
    const isKmzUrl = urlLower.endsWith('.kmz');

    function fetchAsText() {
        return fetch(url).then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); });
    }
    function fetchAsBinary() {
        return fetch(url).then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.arrayBuffer(); });
    }

    function handleError(err) {
        console.error('URL import failed:', err);
        alert('Failed to fetch data from URL.\n' + err.message);
        btn.disabled = false; btn.textContent = 'Fetch & Import';
    }

    /* ── GPX URL ─────────────────────────────── */
    if (isGPXUrl) {
        fetchAsText().then(gpxText => {
            importPendingFeatures = parseGPX(gpxText);
            if (importPendingFeatures.length === 0) { alert('No compatible features found in GPX.'); return; }
            renderPreview(importPendingFeatures);
        }).catch(handleError).finally(() => { btn.disabled = false; btn.textContent = 'Fetch & Import'; });
        return;
    }

    /* ── KML URL ─────────────────────────────── */
    if (isKmlUrl) {
        fetchAsText().then(kmlText => {
            importPendingFeatures = parseKML(kmlText);
            if (importPendingFeatures.length === 0) { alert('No compatible features found in KML.'); return; }
            renderPreview(importPendingFeatures);
        }).catch(handleError).finally(() => { btn.disabled = false; btn.textContent = 'Fetch & Import'; });
        return;
    }

    /* ── KMZ URL (zipped) ────────────────────── */
    if (isKmzUrl) {
        if (typeof JSZip === 'undefined') { alert('JSZip library not loaded. Please refresh the page and try again.'); btn.disabled = false; btn.textContent = 'Fetch & Import'; return; }
        fetchAsBinary().then(buf => JSZip.loadAsync(buf))
            .then(zip => {
                const kmlFile = Object.keys(zip.files).find(f => f.toLowerCase().endsWith('.kml'));
                if (!kmlFile) throw new Error('No KML file found inside KMZ');
                return zip.files[kmlFile].async('string');
            }).then(kmlText => {
                importPendingFeatures = parseKML(kmlText);
                if (importPendingFeatures.length === 0) { alert('No compatible features found in KMZ.'); return; }
                renderPreview(importPendingFeatures);
            }).catch(handleError).finally(() => { btn.disabled = false; btn.textContent = 'Fetch & Import'; });
        return;
    }

    /* ── Generic: try GeoJSON → KML → GPX ────── */
    const CORS_PROXIES = ['', 'https://corsproxy.io/?', 'https://api.allorigins.win/raw?url='];

    function tryFetchWithProxy(proxyIdx) {
        const target = CORS_PROXIES[proxyIdx] ? CORS_PROXIES[proxyIdx] + encodeURIComponent(url) : url;
        return fetch(target).then(r => {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.text().then(t => {
                if (t.includes('<kml') || t.includes('<Document') || t.includes('<Placemark')) return { text: t, format: 'kml' };
                if (t.includes('<gpx')) return { text: t, format: 'gpx' };
                try { JSON.parse(t); return { text: t, format: 'geojson' }; } catch (_) {}
                return { text: t, format: 'unknown' };
            });
        });
    }

    function attemptImport(proxyIdx) {
        if (proxyIdx >= CORS_PROXIES.length) {
            btn.disabled = false; btn.textContent = 'Fetch & Import';
            alert('Could not import data from this URL.\nMake sure the URL points to a GeoJSON, KML, or GPX file.');
            return;
        }
        tryFetchWithProxy(proxyIdx).then(result => {
            let parsed = false;
            if (result.format === 'geojson') {
                try { importPendingFeatures = parseGeoJSONForPreview(JSON.parse(result.text)); parsed = importPendingFeatures.length > 0; } catch (_) {}
            } else if (result.format === 'kml') {
                try { importPendingFeatures = parseKML(result.text); parsed = importPendingFeatures.length > 0; } catch (_) {}
            } else if (result.format === 'gpx') {
                try { importPendingFeatures = parseGPX(result.text); parsed = importPendingFeatures.length > 0; } catch (_) {}
            }
            if (parsed) { renderPreview(importPendingFeatures); btn.disabled = false; btn.textContent = 'Fetch & Import'; }
            else { attemptImport(proxyIdx + 1); }
        }).catch(() => attemptImport(proxyIdx + 1));
    }

    attemptImport(0);
}

/* ── Save Modal ────────────────────────────────── */
function wireSaveModal() {
    $('#btn-save-map').addEventListener('click', () => {
        if (S.annotations.length === 0) { alert('No annotations to save.'); return; }
        $('#save-modal').classList.remove('hidden');
        $('#save-name-input').value = '';
        setTimeout(() => $('#save-name-input').focus(), 100);
    });
    $('#save-cancel-btn').addEventListener('click', () => $('#save-modal').classList.add('hidden'));
    $('#save-modal').addEventListener('click', e => {
        if (e.target === $('#save-modal')) $('#save-modal').classList.add('hidden');
    });
    $('#save-confirm-btn').addEventListener('click', () => {
        const name = $('#save-name-input').value.trim();
        if (!name) { alert('Please enter a name.'); return; }
        saveMapToStorage(name, S.annotations);
        $('#save-modal').classList.add('hidden');
        $('#status-text').textContent = 'Map saved as "' + name + '"';
    });
    $('#save-name-input').addEventListener('keydown', e => {
        if (e.key === 'Enter') $('#save-confirm-btn').click();
        if (e.key === 'Escape') $('#save-modal').classList.add('hidden');
    });
}

/* =====================================================
   Map Events
   ===================================================== */
let mouseDown = false;

map.on('mousedown', e => {
    if (e.originalEvent && e.originalEvent.button !== 0) return; /* only left button */
    mouseDown = true;
    if (S.tool === 'freehand') startFreehand(e);
    if (S.tool === 'arrow') startArrow(e);
    if (S.tool === 'eraser') eraserDragStart();
});

map.on('mousemove', e => {
    S.lastLatLng = e.latlng;
    if (S.tool === 'freehand' && S.drawing) moveFreehand(e);
    if (S.tool === 'arrow' && S.arrowDrawing) moveArrow(e);
    if (S.tool === 'eraser' && S.eraserDragging) eraserDragMove(e);
    if (S.tool === 'measure') moveMeasurePreview(e);
});

map.on('mouseup', e => {
    mouseDown = false;
    if (S.tool === 'freehand' && S.drawing) finishFreehand();
    if (S.tool === 'arrow' && S.arrowDrawing) finishArrow();
    if (S.tool === 'eraser') eraserDragEnd();
});

map.on('click', e => {
    if (S.tool === 'marker') placeMarker(e);
    if (S.tool === 'fire') placeFire(e);
    if (S.tool === 'measure') startMeasure(e);
    if (S.tool === 'label') {
        const pt = map.latLngToContainerPoint(e.latlng);
        showLabelInput(e.latlng, { x: pt.x + 100, y: pt.y + document.getElementById('map').offsetTop });
    }
});

map.on('dblclick', e => {
    if (S.tool === 'measure') {
        if (e && e.originalEvent) L.DomEvent.stop(e.originalEvent);
        finishMeasure();
    }
    /* Clear highlight when double-clicking empty map area (only in pan mode) */
    if (S.tool === 'pan' && S.highlighted) {
        S.highlighted.setStyle(S.highlightedOrigStyle);
        S.highlighted.bringToBack();
        S.highlighted = null;
        S.highlightedOrigStyle = null;
    }
});

/* touch support (Leaflet normalises most, but explicit is safer) */
map.on('touchstart', e => {
    if (S.tool === 'freehand' && e.latlng) startFreehand(e);
});
map.on('touchmove', e => {
    if (S.tool === 'freehand' && S.drawing && e.latlng) moveFreehand(e);
});
map.on('touchend', () => {
    if (S.tool === 'freehand' && S.drawing) finishFreehand();
});

map.on('zoomend', () => {
    $('#zoom-display').textContent = 'Zoom: ' + map.getZoom();
});

/* =====================================================
   UI — Tool Buttons
   ===================================================== */
$$('.tool-btn').forEach(btn => {
    btn.addEventListener('click', () => setTool(btn.dataset.tool));
});

/* =====================================================
   UI — Color Swatches (generated dynamically)
   ===================================================== */
COLORS.forEach((c, i) => {
    const el = document.createElement('button');
    el.className = 'color-swatch' + (i === 0 ? ' active' : '');
    el.dataset.color = c;
    el.style.background = c;
    if (c === '#333333') el.style.boxShadow = 'inset 0 0 0 1px #666';
    el.title = c;
    el.addEventListener('click', () => setColor(c));
    $('#color-grid').appendChild(el);
});

function setColor(c) {
    S.color = c;
    $$('.color-swatch').forEach(s => s.classList.toggle('active', s.dataset.color === c));
    $('#hex-input').value = c.replace('#', '');
}

$('#hex-input').addEventListener('input', e => {
    const val = e.target.value.replace(/[^0-9a-fA-F]/g, '');
    if (val.length === 6) {
        const c = '#' + val.toLowerCase();
        S.color = c;
        $$('.color-swatch').forEach(s => s.classList.toggle('active', s.dataset.color === c));
    }
});

/* =====================================================
   UI — Weight Slider
   ===================================================== */
$('#weight-slider').addEventListener('input', e => {
    S.weight = parseInt(e.target.value, 10);
    $('#weight-val').textContent = S.weight;
});

/* =====================================================
   UI — Style Buttons
   ===================================================== */
$$('.style-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        S.dashStyle = btn.dataset.style;
        $$('.style-btn').forEach(b => b.classList.toggle('active', b.dataset.style === S.dashStyle));
    });
});

/* =====================================================
   UI — Action Buttons
   ===================================================== */
$('#btn-lock').addEventListener('click', toggleLockAll);
$('#btn-clear').addEventListener('click', clearAll);
$('#btn-png').addEventListener('click', exportPNG);
$('#btn-geojson').addEventListener('click', exportGeoJSON);
$('#btn-finish').addEventListener('click', () => {
    if (S.tool === 'measure') finishMeasure();
});
$('#btn-undo').addEventListener('click', undo);
$('#btn-redo').addEventListener('click', redo);

/* =====================================================
   Keyboard Shortcuts
   ===================================================== */
document.addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
    /* Ctrl+Z / Ctrl+Y undo/redo */
    if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) { e.preventDefault(); undo(); return; }
    if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) { e.preventDefault(); redo(); return; }
    switch (e.key) {
        case 'Escape':
            if (!$('#proxy-modal').classList.contains('hidden')) { closeProxyModal(); break; }
            if (!$('#import-modal').classList.contains('hidden')) { closeImportModal(); break; }
            if (!$('#overlay-modal').classList.contains('hidden')) { closeOverlayModal(); break; }
            if (!$('#save-modal').classList.contains('hidden')) { $('#save-modal').classList.add('hidden'); break; }
            if (overlayPlacement) { cancelOverlayPlacement(); break; }
                if (S.tool === 'measure') cancelMeasure();
            if (S.tool === 'label') hideLabelInput();
            break;
        case 'Enter':
            if (!$('#import-modal').classList.contains('hidden')) { confirmImport(); break; }
            if (S.tool === 'measure') finishMeasure();
            break;
        case '1': setTool('pan');      break;
        case '2': setTool('freehand'); break;
        case '4': setTool('arrow');    break;
        case '5': setTool('marker');   break;
        case '6': setTool('label');    break;
        case '7': setTool('measure');  break;
        case '8': setTool('eraser');   break;
        case '9': setTool('fire');     break;
        case 'i': case 'I': openImportModal(); break;
        case 'f': case 'F': toggleFullscreen(); break;
    }
});

/* =====================================================
   Fullscreen Mode
   ===================================================== */
const fsBtn = $('#btn-fullscreen');

function toggleFullscreen() {
    const isFs = !!(document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement);
    if (!isFs) {
        const el = document.documentElement;
        if (el.requestFullscreen) {
            el.requestFullscreen().catch(function (err) { console.warn('[FS] requestFullscreen failed:', err); });
        } else if (el.webkitRequestFullscreen) {
            el.webkitRequestFullscreen();
        } else if (el.msRequestFullscreen) {
            el.msRequestFullscreen();
        } else {
            console.warn('[FS] Fullscreen API not supported');
        }
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen().catch(function (err) { console.warn('[FS] exitFullscreen failed:', err); });
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }
}

function updateFullscreenBtn() {
    const isFs = !!(document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement);
    console.log('[FS] fullscreen changed, isFs =', isFs);
    if (fsBtn) {
        fsBtn.textContent = isFs ? '⛶ Exit Fullscreen' : '⛶ Fullscreen';
        fsBtn.title = isFs ? 'Exit fullscreen (F)' : 'Toggle fullscreen (F)';
    }
}

if (fsBtn) {
    fsBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        toggleFullscreen();
    });
}
document.addEventListener('fullscreenchange', function () { updateFullscreenBtn(); setTimeout(requestMapResize, 350); });
document.addEventListener('webkitfullscreenchange', function () { updateFullscreenBtn(); setTimeout(requestMapResize, 350); });

/* =====================================================
   Draggable Panels
   ===================================================== */
const DRAG_STORAGE_KEY = 'map-panel-layout';
const SETTINGS_STORAGE_KEY = 'map-layout-settings';
const PRESETS_STORAGE_KEY = 'map-layout-presets';
const SNAP_THRESHOLD = 12;

let cfgSnapEdge = true;

function makeDraggable(el, handleEl, id) {
    /* Guard: a panel or its grip may not exist on every page variant.
       Without this the whole script died with a TypeError and every feature
       defined after it (including the proxy modal) never initialised. */
    if (!el) return;
    if (!handleEl) handleEl = el;
    let isDragging = false, startX, startY, origLeft, origTop;
    el.classList.add('draggable');
    el.dataset.draggableId = id;

    function startDrag(e) {
        if (e.button && e.button !== 0) return;
        e.preventDefault(); e.stopPropagation();
        isDragging = true;
        const rect = el.getBoundingClientRect();
        const cx = e.touches ? e.touches[0].clientX : e.clientX;
        const cy = e.touches ? e.touches[0].clientY : e.clientY;
        startX = cx; startY = cy;
        origLeft = rect.left; origTop = rect.top;
        /* switch from CSS anchoring to absolute top/left */
        el.style.left = origLeft + 'px';
        el.style.top  = origTop + 'px';
        el.style.bottom = 'auto';
        el.style.right  = 'auto';
        el.style.transform = 'none';
        el.classList.add('dragging');
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', endDrag);
        document.addEventListener('touchmove', onMove, { passive: false });
        document.addEventListener('touchend', endDrag);
    }

    function onMove(e) {
        if (!isDragging) return;
        e.preventDefault();
        const cx = e.touches ? e.touches[0].clientX : e.clientX;
        const cy = e.touches ? e.touches[0].clientY : e.clientY;
        let nl = origLeft + (cx - startX);
        let nt = origTop  + (cy - startY);
        /* clamp to viewport */
        nl = Math.max(0, Math.min(window.innerWidth  - el.offsetWidth,  nl));
        nt = Math.max(0, Math.min(window.innerHeight - el.offsetHeight, nt));
        /* snap to edges */
        if (cfgSnapEdge) {
            if (nl < SNAP_THRESHOLD) nl = 0;
            if (nt < SNAP_THRESHOLD) nt = 0;
            if (nl + el.offsetWidth  > window.innerWidth  - SNAP_THRESHOLD) nl = window.innerWidth  - el.offsetWidth;
            if (nt + el.offsetHeight > window.innerHeight - SNAP_THRESHOLD) nt = window.innerHeight - el.offsetHeight;
        }
        el.style.left = nl + 'px';
        el.style.top  = nt + 'px';
    }

    function endDrag() {
        if (!isDragging) return;
        isDragging = false;
        el.classList.remove('dragging');
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', endDrag);
        document.removeEventListener('touchmove', onMove);
        document.removeEventListener('touchend', endDrag);
        saveLayout();
        /* Prevent the document click handler from immediately closing panels */
        window._justDraggedPanel = true;
        setTimeout(function () { window._justDraggedPanel = false; }, 100);
    }

    handleEl.addEventListener('mousedown', startDrag);
    handleEl.addEventListener('touchstart', startDrag, { passive: false });
}

function saveLayout() {
    const pos = {};
    document.querySelectorAll('[data-draggable]').forEach(el => {
        const id = el.dataset.draggable;
        if (el.style.left || el.style.top) {
            pos[id] = { left: parseInt(el.style.left) || 0, top: parseInt(el.style.top) || 0 };
        }
    });
    localStorage.setItem(DRAG_STORAGE_KEY, JSON.stringify(pos));
}

function loadLayout() {
    const raw = localStorage.getItem(DRAG_STORAGE_KEY);
    if (!raw) return;
    try {
        const pos = JSON.parse(raw);
        document.querySelectorAll('[data-draggable]').forEach(el => {
            const p = pos[el.dataset.draggable];
            if (!p) return;
            /* bottom-bar stays centered via CSS — skip restoring its drag position */
            if (el.dataset.draggable === 'bottom-bar') {
                el.style.left = el.style.top = el.style.bottom = el.style.right = el.style.transform = '';
                return;
            }
            el.style.left      = p.left + 'px';
            el.style.top       = p.top  + 'px';
            el.style.bottom    = 'auto';
            el.style.right     = 'auto';
            el.style.transform = 'none';
        });
    } catch (_) { /* ignore corrupt data */ }
}

function resetLayout() {
    document.querySelectorAll('[data-draggable]').forEach(el => {
        el.style.left = el.style.top = el.style.bottom = el.style.right = el.style.transform = '';
    });
    localStorage.removeItem(DRAG_STORAGE_KEY);
    /* restore checkboxes */
    $('#cfg-show-toolbar').checked  = true;
    $('#cfg-show-style').checked    = true;
    $('#cfg-show-bottombar').checked = true;
    $('#cfg-snap-edge').checked     = true;
    cfgSnapEdge = true;
    applyVisibility();
    saveSettings();
}

function clampDraggablePanels() {
    const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
    const viewportHeight = document.documentElement.clientHeight || window.innerHeight;
    let changed = false;

    /* Collect all draggable panels and their rects first */
    const panels = [];
    document.querySelectorAll('[data-draggable]').forEach(el => {
        const isManuallyPos = el.style.left || el.style.top;
        panels.push({ el, isManuallyPos, rect: el.getBoundingClientRect() });
    });

    /* Step 1: Clamp each manually-positioned panel inside the viewport */
    panels.forEach(p => {
        if (!p.isManuallyPos) return;
        const left = Math.max(0, Math.min(viewportWidth - p.el.offsetWidth, p.rect.left));
        const top = Math.max(0, Math.min(viewportHeight - p.el.offsetHeight, p.rect.top));
        if (Math.round(p.rect.left) !== Math.round(left) || Math.round(p.rect.top) !== Math.round(top)) {
            p.el.style.left = left + 'px';
            p.el.style.top = top + 'px';
            p.rect = p.el.getBoundingClientRect(); /* refresh after move */
            changed = true;
        }
    });

    /* Step 2: Prevent overlap between draggable panels.
       If two manually-positioned panels overlap, push the second one down
       so it sits just below the first. */
    const GAP = 8; /* minimum gap between panels in px */
    for (let i = 0; i < panels.length; i++) {
        const a = panels[i];
        if (!a.isManuallyPos) continue;
        const aRect = a.el.getBoundingClientRect();
        for (let j = 0; j < panels.length; j++) {
            if (i === j) continue;
            const b = panels[j];
            if (!b.isManuallyPos) continue;
            const bRect = b.el.getBoundingClientRect();
            /* Check if rectangles overlap */
            const overlaps =
                aRect.left < bRect.right  &&
                aRect.right > bRect.left  &&
                aRect.top  < bRect.bottom &&
                aRect.bottom > bRect.top;
            if (overlaps) {
                /* Push panel b below panel a */
                const newTop = Math.round(aRect.bottom + GAP);
                if (newTop + b.el.offsetHeight <= viewportHeight) {
                    b.el.style.top = newTop + 'px';
                } else {
                    /* Not enough room below — push b to the right of a */
                    const newLeft = Math.round(aRect.right + GAP);
                    if (newLeft + b.el.offsetWidth <= viewportWidth) {
                        b.el.style.left = newLeft + 'px';
                    }
                }
                changed = true;
            }
        }
    }

    if (changed) saveLayout();
}

/* ── Panel Visibility ──────────────────────────── */
function applyVisibility() {
    const tb = $('#toolbar'), sp = $('#style-panel'), bb = $('#bottom-bar');
    if (tb)  tb.style.display  = $('#cfg-show-toolbar').checked  ? '' : 'none';
    if (sp)  sp.style.display  = $('#cfg-show-style').checked    ? '' : 'none';
    if (bb)  bb.style.display  = $('#cfg-show-bottombar').checked ? '' : 'none';
}

/* ── UI Scale ─────────────────────────────────────── */
function getAutoScale() {
    var dpr = window.devicePixelRatio || 1;
    /* Map DPR to a gentle scale boost: DPR 1→1.0, 1.5→1.15, 2→1.3, capped */
    return Math.min(+(1 + (dpr - 1) * 0.3).toFixed(2), 1.4);
}

function applyUIScale() {
    var auto = $('#cfg-ui-auto').checked;
    var scale;
    if (auto) {
        scale = getAutoScale();
    } else {
        scale = parseInt($('#cfg-ui-scale').value, 10) / 100;
    }
    document.documentElement.style.setProperty('--ui-scale', scale);
    /* Update the label */
    var label = $('#ui-scale-val');
    if (label) {
        label.textContent = auto ? 'Auto (' + Math.round(scale * 100) + '%)' : Math.round(scale * 100) + '%';
    }
    /* Disable slider when auto is on */
    $('#cfg-ui-scale').disabled = auto;
}

function saveSettings() {
    const s = {
        showToolbar:   $('#cfg-show-toolbar').checked,
        showStyle:     $('#cfg-show-style').checked,
        showBottombar: $('#cfg-show-bottombar').checked,
        snapEdge:      $('#cfg-snap-edge').checked,
        uiAuto:        $('#cfg-ui-auto').checked,
        uiScale:       parseInt($('#cfg-ui-scale').value, 10)
    };
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(s));
}

function loadSettings() {
    const raw = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!raw) return;
    try {
        const s = JSON.parse(raw);
        if (s.showToolbar   !== undefined) $('#cfg-show-toolbar').checked   = s.showToolbar;
        if (s.showStyle     !== undefined) $('#cfg-show-style').checked     = s.showStyle;
        if (s.showBottombar !== undefined) $('#cfg-show-bottombar').checked = s.showBottombar;
        if (s.snapEdge      !== undefined) { $('#cfg-snap-edge').checked = s.snapEdge; cfgSnapEdge = s.snapEdge; }
        if (s.uiAuto        !== undefined) $('#cfg-ui-auto').checked = s.uiAuto;
        if (s.uiScale       !== undefined) $('#cfg-ui-scale').value  = s.uiScale;
        applyVisibility();
        applyUIScale();
    } catch (_) {}
}

/* ── Layout Presets ────────────────────────────── */
function getPresets() {
    try { return JSON.parse(localStorage.getItem(PRESETS_STORAGE_KEY)) || []; }
    catch (_) { return []; }
}
function setPresets(arr) { localStorage.setItem(PRESETS_STORAGE_KEY, JSON.stringify(arr)); }

function captureCurrentLayout() {
    const pos = {};
    document.querySelectorAll('[data-draggable]').forEach(el => {
        const r = el.getBoundingClientRect();
        pos[el.dataset.draggable] = { left: Math.round(r.left), top: Math.round(r.top) };
    });
    return pos;
}

function applyPresetPosition(pos) {
    document.querySelectorAll('[data-draggable]').forEach(el => {
        const p = pos[el.dataset.draggable];
        if (!p) return;
        el.style.left      = p.left + 'px';
        el.style.top       = p.top  + 'px';
        el.style.bottom    = 'auto';
        el.style.right     = 'auto';
        el.style.transform = 'none';
    });
    saveLayout();
}

function renderPresets() {
    const list = $('#preset-list-settings');
    const presets = getPresets();
    if (!list) return;
    if (presets.length === 0) {
        list.innerHTML = '<div class="preset-empty">No saved presets</div>';
        return;
    }
    list.innerHTML = '';
    presets.forEach((pr, i) => {
        const div = document.createElement('div');
        div.className = 'preset-item';
        const name = document.createElement('span');
        name.className = 'preset-item-name';
        name.textContent = pr.name;
        name.title = 'Click to load';
        name.addEventListener('click', () => {
            applyPresetPosition(pr.layout);
            if (pr.visibility) {
                $('#cfg-show-toolbar').checked   = pr.visibility.showToolbar  !== false;
                $('#cfg-show-style').checked     = pr.visibility.showStyle    !== false;
                $('#cfg-show-bottombar').checked = pr.visibility.showBottombar !== false;
                applyVisibility();
            }
        });
        const del = document.createElement('button');
        del.className = 'preset-item-del';
        del.textContent = '✕';
        del.title = 'Delete preset';
        del.addEventListener('click', (e) => {
            e.stopPropagation();
            const all = getPresets(); all.splice(i, 1); setPresets(all); renderPresets();
        });
        div.appendChild(name);
        div.appendChild(del);
        list.appendChild(div);
    });
}

function savePreset() {
    const input = $('#preset-name-input');
    const name = input.value.trim();
    if (!name) { input.focus(); return; }
    const all = getPresets();
    all.push({
        name: name,
        layout: captureCurrentLayout(),
        visibility: {
            showToolbar:   $('#cfg-show-toolbar').checked,
            showStyle:     $('#cfg-show-style').checked,
            showBottombar: $('#cfg-show-bottombar').checked
        }
    });
    setPresets(all);
    input.value = '';
    renderPresets();
}

/* Wire up draggables */
(function initDraggables () {
    const toolbar    = document.getElementById('toolbar');
    const stylePanel = document.getElementById('style-panel');
    const bottomBar  = document.getElementById('bottom-bar');

    if (toolbar)    makeDraggable(toolbar,    toolbar.querySelector('.drag-handle'),    'toolbar');
    if (stylePanel) makeDraggable(stylePanel, stylePanel.querySelector('.drag-grip'),   'style-panel');
    if (bottomBar)  makeDraggable(bottomBar,  bottomBar.querySelector('.bar-grip'),     'bottom-bar');

    loadLayout();
    loadSettings();
    applyUIScale();   /* apply default auto-scale if no saved settings */
    renderPresets();
})();

/* =====================================================
   Proxy Setup Modal — OS Detection & Management
   ===================================================== */
let proxyPendingUrl = null;   /* Google Maps URL to retry after proxy starts */
let proxyPollTimer = null;    /* interval ID for polling proxy status */
/* Proxy base URLs. The main one matches the page protocol (an https page can
   never fetch an http://localhost URL — the browser blocks it as mixed
   content), and the alternate is kept as a fallback so a proxy that only
   listens on one protocol still works. */
const _pLocalHttp  = 'http://localhost:8080';
const _pLocalHttps = 'https://localhost:8443';
let _p    = (location.protocol === 'https:' ? _pLocalHttps : _pLocalHttp);
let _pAlt = (_p === _pLocalHttps ? _pLocalHttp : _pLocalHttps);
function setProxyBase(base) {
    _p = base;
    _pAlt = (base === _pLocalHttps ? _pLocalHttp : _pLocalHttps);
}

function detectProxyOS() {
    const ua = navigator.userAgent || '';
    if (/Win/i.test(ua)) return 'Windows';
    if (/Mac/i.test(ua)) return 'macOS';
    if (/Linux/i.test(ua)) return 'Linux';
    if (/Android/i.test(ua)) return 'Android';
    if (/iPhone|iPad|iPod/i.test(ua)) return 'iOS';
    return 'Unknown';
}

function openProxyModal(pendingUrl) {
    proxyPendingUrl = pendingUrl || null;
    const modal = $('#proxy-modal');
    modal.classList.remove('hidden');

    /* Detect OS and set instructions */
    const os = detectProxyOS();
    $('#proxy-os-name').textContent = os;
    document.body.classList.remove('proxy-show-win', 'proxy-show-unix');
    if (/Windows/i.test(os)) {
        document.body.classList.add('proxy-show-win');
    } else {
        document.body.classList.add('proxy-show-unix');
    }

    /* Reset status area */
    const statusEl = $('#proxy-status-text');
    statusEl.textContent = '⏳ Waiting for proxy…';
    statusEl.className = '';
    $('#proxy-status-detail').textContent = 'Run the setup script, then click "Check Proxy Status".';
    $('#proxy-check-btn').style.display = '';
    $('#proxy-retry-btn').style.display = 'none';
}

function closeProxyModal() {
    $('#proxy-modal').classList.add('hidden');
    if (proxyPollTimer) { clearInterval(proxyPollTimer); proxyPollTimer = null; }
    proxyPendingUrl = null;
}

function checkProxyStatus() {
    const statusEl = $('#proxy-status-text');
    const detailEl = $('#proxy-status-detail');
    statusEl.textContent = '🔄 Checking proxy…';
    statusEl.className = '';
    detailEl.textContent = 'Connecting to proxy…';

    function showProxyOk(label) {
        statusEl.textContent = '✅ Proxy is running!';
        statusEl.className = 'proxy-ok';
        detailEl.textContent = label || 'Connected to proxy';
        $('#proxy-check-btn').style.display = 'none';
        $('#proxy-retry-btn').style.display = '';
        if (proxyPollTimer) { clearInterval(proxyPollTimer); proxyPollTimer = null; }
    }

    function tryPing(url, label, base) {
        return fetch(url)
            .then(function (r) { if (!r.ok) throw 0; return r.text(); })
            .then(function (t) {
                if (t.indexOf('pong') !== -1) {
                    if (base) setProxyBase(base);   /* remember which protocol answered */
                    showProxyOk(label);
                    throw 'done';
                }
                throw 0;
            });
    }

    /* Strategy 1: relative URL (same-origin) */
    tryPing('/ping', 'Same-origin /ping OK')
        .catch(function (e) { if (e === 'done') return Promise.reject(e); return null; })
        /* Strategy 2: HTTP localhost */
        .then(function () { return tryPing('http://localhost:8080/ping', 'Proxy OK on http://localhost:8080', _pLocalHttp); })
        .catch(function (e) { if (e === 'done') return Promise.reject(e); return null; })
        /* Strategy 3: HTTPS localhost (for HTTPS websites) */
        .then(function () { return tryPing('https://localhost:8443/ping', 'Proxy OK on https://localhost:8443', _pLocalHttps); })
        .catch(function (e) { if (e === 'done') return Promise.reject(e); return null; })
        /* Strategy 4: no-cors fallback */
        .then(function () { return fetch('http://localhost:8080/ping', { mode: 'no-cors' }); })
        .then(function () { showProxyOk('no-cors OK'); })
        .catch(function (e) {
            if (e === 'done') return;
            statusEl.textContent = '❌ Proxy not running yet';
            statusEl.className = 'proxy-fail';
            const httpsPage = (location.protocol === 'https:');
            detailEl.innerHTML =
                '<b>This page is ' + (httpsPage ? 'HTTPS' : 'HTTP') + '.</b> A browser refuses to let an HTTPS page call <code>http://localhost:8080</code> (mixed content), ' +
                'so the proxy must also listen on <b>HTTPS 8443</b>.<br><br>' +
                '<b>1.</b> Start the proxy again — the current server (' + (httpsPage ? 'globe-server.exe / proxy.js v5+' : 'any') + ') must print both ' +
                '“http://localhost:8080” and “https://localhost:8443”.<br>' +
                '<b>2.</b> Open <a href="https://localhost:8443/ping" target="_blank">https://localhost:8443/ping</a> and accept the certificate ' +
                '(Advanced → Continue to localhost), then click “Check Proxy Status” again.<br><br>' +
                '<b>Local copy of the map:</b> <a href="http://localhost:8080/map.html" target="_blank">http://localhost:8080/map.html</a> — ' +
                'this page is HTTP, so the proxy works there even without HTTPS.';
        });
}

function startProxyPolling() {
    if (proxyPollTimer) clearInterval(proxyPollTimer);
    proxyPollTimer = setInterval(checkProxyStatus, 3000);
    checkProxyStatus();
}

function retryProxyImport() {
    if (!proxyPendingUrl) {
        closeProxyModal();
        return;
    }
    const statusEl = $('#proxy-status-text');
    const detailEl = $('#proxy-status-detail');
    statusEl.textContent = '🔄 Retrying import…';
    statusEl.className = '';
    detailEl.textContent = 'Fetching KML through local proxy…';

    const mid = parseGoogleMapsUrl(proxyPendingUrl);
    if (mid) {
        const kmlUrl = 'https://www.google.com/maps/d/u/0/kml?mid=' + mid + '&forcekml=1';
        fetch(_p + '/kml?url=' + encodeURIComponent(kmlUrl))
            .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
            .then(kmlText => {
                importPendingFeatures = parseKML(kmlText);
                if (importPendingFeatures.length === 0) { alert('No features found in this Google Map.'); closeProxyModal(); return; }
                renderPreview(importPendingFeatures);
                closeProxyModal();
            })
            .catch(err => {
                statusEl.textContent = '❌ Retry failed';
                statusEl.className = 'proxy-fail';
                detailEl.textContent = 'Error: ' + (err.message || 'unknown') + '. Make sure the proxy is running.';
            });
    } else {
        /* Not a Google Maps URL — just try direct fetch through proxy */
        fetch(_p + '/kml?url=' + encodeURIComponent(proxyPendingUrl))
            .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
            .then(text => {
                try {
                    importPendingFeatures = parseKML(text);
                } catch (_) {
                    importPendingFeatures = parseGeoJSONForPreview(JSON.parse(text));
                }
                if (importPendingFeatures.length === 0) { alert('No features found.'); closeProxyModal(); return; }
                renderPreview(importPendingFeatures);
                closeProxyModal();
            })
            .catch(err => {
                statusEl.textContent = '❌ Retry failed';
                statusEl.className = 'proxy-fail';
                detailEl.textContent = 'Error: ' + (err.message || 'unknown');
            });
    }
}

/* =====================================================
   Image Overlay Feature
   ===================================================== */
const OVERLAY_LS_KEY = 'map_image_overlays';
let imageOverlays = [];
let overlayNextId = 1;
let overlayPendingImage = null;
let overlayPlacement = null;

function openOverlayModal() {
    $('#overlay-modal').classList.remove('hidden');
    overlayRefreshList();
}
function closeOverlayModal() {
    $('#overlay-modal').classList.add('hidden');
    if (overlayPlacement) cancelOverlayPlacement();
}

function wireOverlayTabs() {
    $$('.overlay-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            $$('.overlay-tab').forEach(t => t.classList.remove('active'));
            $$('.overlay-tab-content').forEach(c => c.classList.remove('active'));
            tab.classList.add('active');
            const target = $('#overlay-tab-' + tab.dataset.tab);
            if (target) target.classList.add('active');
        });
    });
}

function handleOverlayImageSource(src, name) {
    closeOverlayModal();
    overlayPendingImage = { src: src, name: name };
    overlayPlacement = { step: 0, firstLatLng: null };
    showOverlayPlacementBanner('Click on the map to set the first corner (top-left)');
    map.getContainer().style.cursor = 'crosshair';
}

function showOverlayPlacementBanner(text) {
    var banner = document.getElementById('overlay-placement-banner');
    if (!banner) {
        banner = document.createElement('div');
        banner.id = 'overlay-placement-banner';
        banner.innerHTML = '<span class="banner-text"></span><button class="banner-cancel">Cancel</button>';
        document.body.appendChild(banner);
        banner.querySelector('.banner-cancel').addEventListener('click', cancelOverlayPlacement);
    }
    banner.querySelector('.banner-text').textContent = text;
    banner.style.display = '';
}

function hideOverlayPlacementBanner() {
    var banner = document.getElementById('overlay-placement-banner');
    if (banner) banner.style.display = 'none';
}

function cancelOverlayPlacement() {
    overlayPlacement = null;
    overlayPendingImage = null;
    hideOverlayPlacementBanner();
    map.getContainer().style.cursor = '';
}

function handleOverlayMapClick(e) {
    if (!overlayPlacement || !overlayPendingImage) return false;
    if (overlayPlacement.step === 0) {
        overlayPlacement.firstLatLng = e.latlng;
        overlayPlacement.step = 1;
        showOverlayPlacementBanner('Click to set the second corner (bottom-right), then the image will be placed');
        return true;
    } else if (overlayPlacement.step === 1) {
        var bounds = L.latLngBounds(overlayPlacement.firstLatLng, e.latlng);
        addImageOverlay(overlayPendingImage.src, overlayPendingImage.name, bounds);
        overlayPlacement = null;
        overlayPendingImage = null;
        hideOverlayPlacementBanner();
        map.getContainer().style.cursor = '';
        return true;
    }
    return false;
}

function addImageOverlay(src, name, bounds, opacity, visible) {
    opacity = opacity !== undefined ? opacity : 0.7;
    if (visible === undefined) visible = true;
    var layer = L.imageOverlay(src, bounds, { opacity: opacity, interactive: true, crossOrigin: true });
    if (visible) layer.addTo(map);
    var entry = {
        id: overlayNextId++,
        name: name || ('Overlay ' + imageOverlays.length),
        src: src,
        bounds: [[bounds.getSouth(), bounds.getWest()], [bounds.getNorth(), bounds.getEast()]],
        opacity: opacity,
        visible: visible,
        layer: layer
    };
    imageOverlays.push(entry);
    saveOverlaysToStorage();
    overlayRefreshList();
    $('#status-text').textContent = 'Image overlay "' + entry.name + '" placed.';
}

function removeOverlay(id) {
    var i = imageOverlays.findIndex(function(o) { return o.id === id; });
    if (i === -1) return;
    map.removeLayer(imageOverlays[i].layer);
    imageOverlays.splice(i, 1);
    saveOverlaysToStorage();
    overlayRefreshList();
}

function toggleOverlayVisibility(id) {
    var entry = imageOverlays.find(function(o) { return o.id === id; });
    if (!entry) return;
    entry.visible = !entry.visible;
    if (entry.visible) entry.layer.addTo(map); else map.removeLayer(entry.layer);
    saveOverlaysToStorage();
    overlayRefreshList();
}

function setOverlayOpacity(id, opacity) {
    var entry = imageOverlays.find(function(o) { return o.id === id; });
    if (!entry) return;
    entry.opacity = opacity;
    entry.layer.setOpacity(opacity);
    saveOverlaysToStorage();
}

function renameOverlay(id, newName) {
    var entry = imageOverlays.find(function(o) { return o.id === id; });
    if (!entry) return;
    entry.name = newName || entry.name;
    saveOverlaysToStorage();
    overlayRefreshList();
}

function overlayRefreshList() {
    var container = $('#overlay-list-container');
    if (!container) return;
    if (imageOverlays.length === 0) {
        container.innerHTML = '<div class="overlay-empty">No overlays added yet</div>';
        return;
    }
    container.innerHTML = '';
    imageOverlays.forEach(function(entry) {
        var item = document.createElement('div');
        item.className = 'overlay-item';
        var thumb = document.createElement('img');
        thumb.className = 'overlay-item-thumb';
        thumb.src = entry.src;
        thumb.alt = entry.name;
        thumb.onerror = function() { this.style.display = 'none'; };
        item.appendChild(thumb);
        var info = document.createElement('div');
        info.className = 'overlay-item-info';
        var nameEl = document.createElement('div');
        nameEl.className = 'overlay-item-name';
        nameEl.textContent = entry.name;
        nameEl.title = 'Click to rename';
        nameEl.addEventListener('click', (function(eid) {
            return function() {
                var input = document.createElement('input');
                input.className = 'overlay-item-name-input';
                input.type = 'text';
                input.value = entry.name;
                input.maxLength = 40;
                nameEl.replaceWith(input);
                input.focus();
                input.select();
                function commit() { renameOverlay(eid, input.value.trim()); }
                input.addEventListener('blur', commit);
                input.addEventListener('keydown', function(ev) {
                    if (ev.key === 'Enter') { ev.preventDefault(); input.blur(); }
                    if (ev.key === 'Escape') { input.value = entry.name; input.blur(); }
                    ev.stopPropagation();
                });
            };
        })(entry.id));
        info.appendChild(nameEl);
        var opacityLabel = document.createElement('div');
        opacityLabel.className = 'overlay-item-opacity';
        opacityLabel.textContent = 'Opacity: ' + Math.round(entry.opacity * 100) + '%';
        info.appendChild(opacityLabel);
        item.appendChild(info);
        var actions = document.createElement('div');
        actions.className = 'overlay-item-actions';
        var hideBtn = document.createElement('button');
        hideBtn.className = 'overlay-item-btn hide-btn' + (entry.visible ? '' : ' hidden-overlay');
        hideBtn.textContent = entry.visible ? '\uD83D\uDC41\uFE0F' : '\uD83D\uDEAB';
        hideBtn.title = entry.visible ? 'Hide overlay' : 'Show overlay';
        hideBtn.addEventListener('click', (function(eid) { return function() { toggleOverlayVisibility(eid); }; })(entry.id));
        actions.appendChild(hideBtn);
        var delBtn = document.createElement('button');
        delBtn.className = 'overlay-item-btn delete-btn';
        delBtn.textContent = '\u2715';
        delBtn.title = 'Delete overlay';
        delBtn.addEventListener('click', (function(eid, ename) {
            return function() { if (confirm('Delete overlay "' + ename + '"?')) removeOverlay(eid); };
        })(entry.id, entry.name));
        actions.appendChild(delBtn);
        item.appendChild(actions);
        container.appendChild(item);
        var sliderRow = document.createElement('div');
        sliderRow.className = 'overlay-opacity-row';
        var slider = document.createElement('input');
        slider.type = 'range';
        slider.min = '0';
        slider.max = '100';
        slider.value = Math.round(entry.opacity * 100);
        var valSpan = document.createElement('span');
        valSpan.className = 'overlay-opacity-val';
        valSpan.textContent = Math.round(entry.opacity * 100) + '%';
        slider.addEventListener('input', (function(eid, opLabel) {
            return function() {
                var v = parseInt(slider.value, 10) / 100;
                setOverlayOpacity(eid, v);
                valSpan.textContent = slider.value + '%';
                if (opLabel) opLabel.textContent = 'Opacity: ' + slider.value + '%';
            };
        })(entry.id, opacityLabel));
        slider.addEventListener('mousedown', function(e) { e.stopPropagation(); });
        slider.addEventListener('click', function(e) { e.stopPropagation(); });
        sliderRow.appendChild(slider);
        sliderRow.appendChild(valSpan);
        container.appendChild(sliderRow);
    });
}

function saveOverlaysToStorage() {
    var data = imageOverlays.map(function(o) {
        return { name: o.name, src: o.src, bounds: o.bounds, opacity: o.opacity, visible: o.visible };
    });
    try { localStorage.setItem(OVERLAY_LS_KEY, JSON.stringify(data)); } catch (_) {}
}

function loadOverlaysFromStorage() {
    try {
        var raw = localStorage.getItem(OVERLAY_LS_KEY);
        if (!raw) return;
        var data = JSON.parse(raw);
        if (!Array.isArray(data)) return;
        data.forEach(function(d) {
            if (!d.src || !d.bounds) return;
            var bounds = L.latLngBounds(d.bounds[0], d.bounds[1]);
            addImageOverlay(d.src, d.name, bounds, d.opacity, d.visible);
        });
    } catch (_) {}
}

function wireOverlayModal() {
    $('#btn-overlay').addEventListener('click', openOverlayModal);
    $('#overlay-modal-close').addEventListener('click', closeOverlayModal);
    $('#overlay-modal').addEventListener('click', function(e) {
        if (e.target === $('#overlay-modal')) closeOverlayModal();
    });
    wireOverlayTabs();
    $('#overlay-browse-btn').addEventListener('click', function() { $('#overlay-file-input').click(); });
    $('#overlay-file-input').addEventListener('change', function(e) {
        if (e.target.files.length > 0) {
            var file = e.target.files[0];
            var reader = new FileReader();
            reader.onload = function(ev) {
                handleOverlayImageSource(ev.target.result, file.name.replace(/\.[^.]+$/, ''));
            };
            reader.readAsDataURL(file);
            e.target.value = '';
        }
    });
    var dz = $('#overlay-dropzone');
    if (dz) {
        dz.addEventListener('dragover', function(e) { e.preventDefault(); dz.classList.add('drag-over'); });
        dz.addEventListener('dragleave', function() { dz.classList.remove('drag-over'); });
        dz.addEventListener('drop', function(e) {
            e.preventDefault(); dz.classList.remove('drag-over');
            if (e.dataTransfer.files.length > 0) {
                var file = e.dataTransfer.files[0];
                if (!file.type.startsWith('image/')) { alert('Please drop an image file.'); return; }
                var reader = new FileReader();
                reader.onload = function(ev) {
                    handleOverlayImageSource(ev.target.result, file.name.replace(/\.[^.]+$/, ''));
                };
                reader.readAsDataURL(file);
            }
        });
    }
    $('#overlay-url-btn').addEventListener('click', function() {
        var url = $('#overlay-url-input').value.trim();
        if (!url) { alert('Please enter an image URL.'); return; }
        handleOverlayImageSource(url, url.split('/').pop().replace(/\.[^.]+$/, '') || 'Overlay');
    });
    $('#overlay-url-input').addEventListener('keydown', function(e) {
        if (e.key === 'Enter') $('#overlay-url-btn').click();
        e.stopPropagation();
    });
    map.on('click', function overlayPlacementClick(e) {
        if (handleOverlayMapClick(e)) {
            L.DomEvent.stop(e);
        }
    });
}

/* ── Prevent context menu during arrow tool ─────── */
map.getContainer().addEventListener('contextmenu', function (e) {
    if (S.tool === 'arrow') e.preventDefault();
});

/* Wire up proxy modal buttons */
(function wireProxyModal() {
    $('#proxy-modal-close').addEventListener('click', closeProxyModal);
    $('#proxy-modal').addEventListener('click', e => {
        if (e.target === $('#proxy-modal')) closeProxyModal();
    });
    $('#proxy-check-btn').addEventListener('click', checkProxyStatus);
    $('#proxy-retry-btn').addEventListener('click', retryProxyImport);
})();

/* =====================================================
   Init
   ===================================================== */
$('#zoom-display').textContent = 'Zoom: ' + map.getZoom();
updateCount();
updateUndoRedoUI();
wireImportModal();
wireSaveModal();
wireOverlayModal();
loadOverlaysFromStorage();
setTool('pan');

/* Style panel toggle */
$('#style-toggle').addEventListener('click', (e) => {
    if (e.target.closest('.drag-grip')) return; /* don't toggle when dragging */
    const body = $('#style-panel .panel-body');
    const arrow = $('#style-toggle .toggle-arrow');
    body.classList.toggle('hidden');
    arrow.classList.toggle('open');
});

/* ── Flag Selector Buttons ────────────────────── */
$$('.flag-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        const flag = btn.dataset.flag || null;
        S.flag = flag;
        $$('.flag-btn').forEach(b => b.classList.toggle('active', (b.dataset.flag || null) === S.flag));
    });
});
/* Initialize: select "no flag" by default */
$$('.flag-btn').forEach(b => b.classList.toggle('active', b.dataset.flag === ''));

/* Reset layout button (inside settings popup) */

/* Settings popup toggle */
$('#btn-settings').addEventListener('click', (e) => {
    e.stopPropagation();
    const panel = $('#settings-panel');
    const isOpening = panel.classList.contains('hidden');
    panel.classList.toggle('hidden');
    document.body.classList.toggle('layout-editing', isOpening);
});
/* Close settings popup when clicking outside (but not right after a panel drag) */
document.addEventListener('click', (e) => {
    if (window._justDraggedPanel) return;
    const panel = $('#settings-panel');
    if (panel.classList.contains('hidden')) return;
    if (e.target.closest('#settings-panel') || e.target.closest('#btn-settings')) return;
    panel.classList.add('hidden');
    document.body.classList.remove('layout-editing');
});

/* Settings: panel visibility checkboxes */
['cfg-show-toolbar', 'cfg-show-style', 'cfg-show-bottombar'].forEach(id => {
    $('#' + id).addEventListener('change', () => { applyVisibility(); saveSettings(); });
});
$('#cfg-snap-edge').addEventListener('change', () => {
    cfgSnapEdge = $('#cfg-snap-edge').checked;
    saveSettings();
});

/* Settings: UI scale */
$('#cfg-ui-auto').addEventListener('change', () => { applyUIScale(); saveSettings(); });
$('#cfg-ui-scale').addEventListener('input', () => { applyUIScale(); saveSettings(); });

/* Settings: presets */
$('#btn-preset-save').addEventListener('click', savePreset);
$('#preset-name-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') savePreset(); });
$('#btn-reset-layout2').addEventListener('click', resetLayout);

/* ── Twemoji: render flag emoji as images on Windows ──── */
function parseEmoji(el) {
    if (window.twemoji && el) {
        try { twemoji.parse(el, { folder: 'svg', ext: '.svg' }); } catch (_) {}
    }
}

/* Parse flag panel emoji on load (for flag selector buttons) */
parseEmoji(document.getElementById('flag-grid'));

console.log('Interactive Map loaded.');
